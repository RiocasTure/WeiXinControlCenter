﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Text;
using System.Web;
using DAO;
using Leo.Project.CC.DAO;
using Leo.Project.CC.Model;
using Leo.Project.Common.Helper;
using Leo.Project.Common.Utility;
using LEO.Common.Tools.WeiXin;
using Newtonsoft.Json.Linq;
using Tools;
using WebChatInterface.Class.Model.WXMsg.Send;
using WebChatInterface.Class.Tencent;

namespace ControlCenterWeChatNotify
{
    class Program
    {
        static void Main(string[] args)
        {
            //將輸入的參數進行ＡＥＳ加密或解密,作用？？？？？？
            if (args != null && args.Length > 0)
            {
                if ((args[0] == "-e" || args[0] == "-d") && args.Length > 1)
                {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 1; i < args.Length; i++)
                    {
                        if (i > 1) sb.Append(' ');
                        sb.Append(args[i]);
                    }
                    bool e = (args[0] == "-e");
                    Console.WriteLine("AES " + (e ? "Encrypt" : "Decrypt") + " Result:");
                    Console.WriteLine(e ? AESHelper.AESEncrypt(sb.ToString()) : AESHelper.AESDecrypt(sb.ToString()));
                }
                else
                    Console.WriteLine("usage:xxx.exe -e|-d txt");
                return;
            }
            LogHelper.Info("ControlCenterWeChatNotify Start!");
            DateTime now = DateTime.Now;
            bool isRest = false;
            //日班休：12:00-13:00
            //夜班休：23:00-00:00、03:00-04:00
            if (now.Hour >= 8 && now.Hour < 19) //日班
            {
                //休息時間
                if (now.Hour == 12) isRest = true;
            }
            else if (now.Hour > 19 || now.Hour < 7) //夜班
            {
                //休息時間
                if (now.Hour == 23 || now.Hour == 3) isRest = true;
            }
            else isRest = true;
            if (isRest)
            {
                //輸出日誌：休息時間不執行該程序
                LogHelper.Info("Rest Time! End.");
                return;
            }
            try
            {
                NotifyByWeiXin_Query();
            }
            catch (Exception ex)
            {
                LogHelper.Error("ControlCenterWeChatNotify Exception!", ex);
            }
        }

        static int CountPage(int rowCount, int pageSize)
        {
            if (pageSize <= 0)
            {
                return rowCount > 0 ? 1 : 0;
            }
            else
            {
                int r = rowCount % pageSize;
                return (rowCount - r) / pageSize + (r > 0 ? 1 : 0);
            }
        }
        static void AddGroupNewsList(int pageSize, string titlePref,string msg, string agentId, string users, string parties, List<SendNews> newsList)
        {
            string[] tx = msg.Split('︴');
            int page = CountPage(tx.Length, pageSize);
            string split = (new String(' ', (int)(tx.Length / 10)));
            for (int i = 0; i < page; i++)
            {
                string tmp = "";
                int start = i * pageSize;
                int end = ((i + 1) * pageSize) > tx.Length ? tx.Length - 1 : ((i + 1) * pageSize - 1);
                for (int j = start; j < end + 1; j++)
                {
                    string sp = ((j+1<10)?" ":"")+(new String(' ', (int)(tx.Length / 10) - (int)((j + 1) / 10)));
                    tmp = (string.IsNullOrEmpty(tmp) ? "" : (tmp + "\r\n")) + (j + 1).ToString() + "." + sp + tx[j].Replace("∥", split);
                }
                SendNews news = new SendNews();
                news.AgentID = agentId;
                if (!string.IsNullOrEmpty(parties)) news.ToParties = parties;
                if (!string.IsNullOrEmpty(users)) news.ToUsers = ConvertUsers(users);
                news.AddNewsItem(titlePref + "(" + tx.Length + "條" + (page <= 1 ? "" : (" : " + (end > start ? ((start + 1).ToString() + "～" + (end + 1).ToString()) : ("第" + (start + 1).ToString() + "条")))) + ")", tmp, "", "");
                newsList.Add(news);
            }
        }
        static void NotifyByWeiXin_Query()
        {
            string tmIcon = "☆", lrIcon = "△";
            int bufferMinute = 10;//10分鐘緩衝期
            DataSet data = SqlHelper.ExecuteDataset(SqlHelper.GetConnection("ControlCenterDatabase"),
                "select * from ARLSForQYWechat_test", null);
                //"select * from (select distinct cLineName,Sup.arrm_cCnName as cSuperviser,Sup.arrm_cEnName as cSuperviserNo,"+
                //"Chf.arrm_cCnName as cChiefof,Chf.arrm_cEnName as cChiefofNo,cSO,cProcessName,dProductionStartTime,dLastReportTime,"+
                //"iPEPlanQtyPer=convert(varchar(20),iPEPlanQtyPer)+cTkbUnitName+'/'+convert(varchar(20),iPEWorkerCount)+N'人',"+
                //"iPlanQtyPer=convert(varchar(20),iPlanQtyPer)+cTkbUnitName+'/'+convert(varchar(20),iWorkerCount)+N'人',"+
                //"iComplianceRate,iCurrentComplianceRate=(select top 1 case when arcpld_iLinePlanQtyPer=0 then 0 else "+
                //"round(isnull(arcpld_fStepSpeed,0)*100.0/arcpld_iLinePlanQtyPer,0) end from ARReportCommonPalletLineDetail_arcpld "+
                //"where arcpld_iIsDeleted=0 and arcpld_iUseTime is not null and arcpld_cLineJobDetailID=cLineJobDetailID order by "+
                //"arcpld_dReportTime desc),dNextReportTime=dateadd(ss,iReportTimeInterval,isnull(dLastReportTime,dProductionStartTime)) "+
                //"from vieArVirtualLineInfo LineInfo inner join ARLineCurrentJobInfo_alcji CurJob on alcji_cLineNo=VirtualLineID "+
                //"inner join [vieARLineJobData] JobData on cLineJobMasterID=alcji_cCurrintJobID "+
                //"inner join vieArLineJobMaster JobMaster on LineJobMasterID=alcji_cCurrintJobID "+
                //"left join ARRoleUserMaster_arrm Sup on Sup.arrm_cID=cSuperviseID "+
                //"left join ARRoleUserMaster_arrm Chf on Chf.arrm_cID=ChifeofID "+
                //"where alcji_cCurrintJobID is not null and LineInfo.FactoryCode='Factory7')Main",null);
            //判斷查詢記錄數目
            LogHelper.Info(data.Tables[0].Rows.Count + " records found!");
            //若查詢記錄表數目大於0且表行數大于0
            if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
            {
                List<WXNotify> notifyList = new List<WXNotify>();
                List<SendNews> groupNewsList = new List<SendNews>();
                Dictionary<string, DateTime> cache = LoadData();
                Dictionary<string, string> groupMsgs = new Dictionary<string, string>();
                foreach (DataRow row in data.Tables[0].Rows)
                {
                    string lineName = Convert.ToString(row["cLineName"]).Trim();
                    DateTime? lastReportTime = null;
                    if (row["dLastReportTime"] != System.DBNull.Value) lastReportTime = Convert.ToDateTime(row["dLastReportTime"]);
                    DateTime? lineStartTime = null;
                    if (row["dProductionStartTime"] != System.DBNull.Value) lineStartTime = Convert.ToDateTime(row["dProductionStartTime"]);
                    DateTime? _nextReportTime = null;
                    if (row["dNextReportTime"] != System.DBNull.Value) _nextReportTime = Convert.ToDateTime(row["dNextReportTime"]);
                    int rate = (row["iCurrentComplianceRate"] != System.DBNull.Value) ? Convert.ToInt32(row["iCurrentComplianceRate"]) : 0;
                    string superviser = Convert.ToString(row["cSuperviser"]);
                    string superviserNo = Convert.ToString(row["cSuperviserNo"]);
                    string chiefNo = Convert.ToString(row["cChiefofNo"]);
                    string SONo = Convert.ToString(row["cSO"]);
                    string Process = Convert.ToString(row["cProcessName"]);
                    string planQtyPE = Convert.ToString(row["iPEPlanQtyPer"]);
                    string planQty = Convert.ToString(row["iPlanQtyPer"]);
                    //獲取生產線生產資料
                    ProductionCheck pc = ConvertProductionCheck(row);
                    DateTime now = DateTime.Now;
                    DateTime? nextReportTime = null;
                    //计算下次报数时间
                    if (lastReportTime.HasValue)
                    {
                        pc.NextReportTime = ((now.Hour == 13 && lastReportTime.Value.Hour <= 12) || (now.Hour == 0 && lastReportTime.Value.Hour <= 23) || (now.Hour == 4 && lastReportTime.Value.Hour <= 3)) ? lastReportTime.Value.AddMinutes(120) : lastReportTime.Value.AddMinutes(60);
                        nextReportTime = pc.NextReportTime.Value.AddMinutes(bufferMinute);
                    }
                    else
                    {
                        pc.NextReportTime = lineStartTime.Value.AddMinutes(60);//60分钟未报数
                        nextReportTime = pc.NextReportTime.Value.AddMinutes(bufferMinute);
                    }

                    string alertTitle = null;
                    string descTitle = "SO：" + SONo + "，督導：" + superviser;
                    string warnType = null;
                    //超时未报数
                    if ((now - nextReportTime.Value).TotalSeconds > 0)
                    {
                        //通知信息標題：類型圖標＋類型名稱＋生產線名
                        alertTitle = tmIcon+"報數超時：" + lineName;
                        string lstRT = (lastReportTime.HasValue ? lastReportTime.Value.ToString("HH:mm") : "未報數");
                        alertTitle += "\r\n上次報數：" + lstRT;
                        string staffTimeoutMsg = groupMsgs.ContainsKey("0_0") ? groupMsgs["0_0"] : null;
                        staffTimeoutMsg = (string.IsNullOrEmpty(staffTimeoutMsg) ? "" : (staffTimeoutMsg + "︴")) + superviser + "，" + lineName + "，" + SONo + "\r\n　∥上次報數：" + (lastReportTime.HasValue ? lastReportTime.Value.ToString("HH:mm") : "未報數");
                        groupMsgs["0_0"] = staffTimeoutMsg;
                        string chiefMsgs = groupMsgs.ContainsKey(chiefNo + "_0") ? groupMsgs[chiefNo + "_0"] : null;
                        chiefMsgs = (string.IsNullOrEmpty(chiefMsgs) ? "" : (chiefMsgs + "︴")) + superviser + "，" + lineName + "，" + SONo + "\r\n　∥上次報數：" + (lastReportTime.HasValue ? lastReportTime.Value.ToString("HH:mm") : "未報數");
                        groupMsgs[chiefNo + "_0"] = chiefMsgs;
                        warnType = Constants.WXNotify_WarnType_ReportTimeout;
                    }
                    //效率不达标
                    else if (rate > 0 && rate < 80)
                    {
                        bool repeatAlert = cache.ContainsKey(lineName) && cache[lineName] != null && (lastReportTime.Value - cache[lineName]).TotalSeconds == 0;
                        if (!repeatAlert)
                        {
                            alertTitle = lrIcon+"效率低下：" + lineName;
                            alertTitle += "\r\n效率：" + rate + "％";// +"\r\nSO：" + SONo + "\r\n督導：" + superviser + "\r\n工序：" + Process + "\r\nPE定額：" + planQtyPE + "\r\n現場定額：" + planQty;
                            string staffSlowMsg = groupMsgs.ContainsKey("0_1") ? groupMsgs["0_1"] : null;
                            staffSlowMsg = (string.IsNullOrEmpty(staffSlowMsg) ? "" : (staffSlowMsg + "︴")) + superviser + "，" + lineName + "，效率" + rate + "%\r\n　∥" + SONo + "，" + Process + "\r\n　∥PE定額" + planQtyPE + "\r\n　∥現場定額" + planQty;
                            groupMsgs["0_1"] = staffSlowMsg;
                            string chiefMsgs = groupMsgs.ContainsKey(chiefNo + "_1") ? groupMsgs[chiefNo + "_1"] : null;
                            chiefMsgs = (string.IsNullOrEmpty(chiefMsgs) ? "" : (chiefMsgs + "︴")) + superviser + "，" + lineName + "，效率" + rate + "%\r\n　∥" + SONo + "，" + Process + "\r\n　∥PE定額" + planQtyPE + "\r\n　∥現場定額" + planQty;
                            groupMsgs[chiefNo + "_1"] = chiefMsgs;
                            warnType = Constants.WXNotify_WarnType_LowSpeed;
                        }
                    }
                    //向督導發送生產線監控消息
                    if (!string.IsNullOrEmpty(alertTitle) && !string.IsNullOrEmpty(warnType))
                    {
                        if (pc != null)
                        {
                            int res = ProductionCheckDAO.Instance.Insert(pc);
                        }
                        WXNotify wxntf = new WXNotify();
                        wxntf.Target = superviserNo;
                        wxntf.WarnType = warnType;
                        wxntf.Status = Constants.WXNotify_Status_Default;
                        wxntf.CreateTime = DateTime.Now;
                        wxntf.LastUpdate = DateTime.Now;
                        if (pc != null && pc.ID > 0) wxntf.CheckID = pc.ID;
                        int result = WXNotifyDAO.Instance.Insert(wxntf);
                        if (result > 0)
                        {
                            LogHelper.Info("WXNotify Inserted! ID=" + wxntf.ID);
                            wxntf.WXNews = new SendNews();
                            wxntf.WXNews.AgentID = "1000003";//贺卡急救（九期）
                            wxntf.WXNews.ToUsers = ConvertUsers(superviserNo);
                            wxntf.WXNews.AddNewsItem(alertTitle, "", "","http://www.astros.com.cn/01/demo/cc-follow.html?state=v_" + wxntf.ID);
                            wxntf.WXNews.AddNewsItem(descTitle, "", "", "http://www.astros.com.cn/01/demo/cc-follow.html?state=v_" + wxntf.ID);
                            wxntf.WXNews.AddNewsItem("接收並跟進處理中", "", "http://www.astros.com.cn/01/icons/icon-follow.jpg", "http://www.astros.com.cn/01/demo/cc/Default.aspx?state=" + HttpUtility.UrlEncode("f_" + wxntf.ID, System.Text.Encoding.UTF8));
                            wxntf.WXNews.AddNewsItem("已完成跟進及改善", "", "http://www.astros.com.cn/01/icons/icon-done.jpg", "http://www.astros.com.cn/01/demo/cc/Default.aspx?state=" + HttpUtility.UrlEncode("d_" + wxntf.ID, System.Text.Encoding.UTF8));
                            wxntf.WXNews.AddNewsItem("需要升級處理", "", "http://www.astros.com.cn/01/icons/icon-upgrade.jpg", "http://www.astros.com.cn/01/demo/cc/Default.aspx?state=" + HttpUtility.UrlEncode("u_" + wxntf.ID, System.Text.Encoding.UTF8));
                            notifyList.Add(wxntf);
                        }
                        else
                        {
                            LogHelper.Error("WXNotify Inserted Fail!\r\n" + JsonUtil<WXNotify>.JsonSerializerObject(wxntf), null);
                        }
                    }
                    //更新本地缓存的上次报数时间
                    if (lastReportTime.HasValue) cache[lineName] = lastReportTime.Value;
                }
                
                //發出消息至指定頻道　
                if (groupMsgs.Count > 0)
                {
                    foreach (KeyValuePair<string, string> msg in groupMsgs)
                    {
                        string[] kv = msg.Key.Split('_');
                        if (kv != null && kv.Length == 2)
                        {
                            if (kv[1] == "0")//超时未报数
                            {
                                if (kv[0] == "0")//团队接收
                                    AddGroupNewsList(6, tmIcon + "報數超時", msg.Value, "1000002", null, "4", groupNewsList);
                                else//科长个人接收
                                    AddGroupNewsList(6, tmIcon + "報數超時", msg.Value, "1000003", ConvertUsers(kv[0]), null, groupNewsList);
                            }
                            else if (kv[1] == "1")//效率不达标
                            {
                                if (kv[0] == "0")//团队接收
                                    AddGroupNewsList(3, lrIcon + "生產效率不達標", msg.Value, "1000002", null, "4", groupNewsList);
                                else//科长个人接收
                                    AddGroupNewsList(3, lrIcon + "生產效率不達標", msg.Value, "1000003", ConvertUsers(kv[0]), null, groupNewsList);
                            }
                        }
                    }
                }
                //發送給督導個人
                SendWeiXinNotify(notifyList);
                //發送給團隊和科長個人接收
                SendNewsByWeiXin(groupNewsList);
                //保存發送消息記錄至數據庫
                SaveData(cache);
            }
            data.Clear();

        }

        private static ProductionCheck ConvertProductionCheck(DataRow row)
        {
            ProductionCheck obj = new ProductionCheck();
            if (!Convert.IsDBNull(row["cLineName"])) obj.LineName = Convert.ToString(row["cLineName"]);
            if (!Convert.IsDBNull(row["dProductionStartTime"])) obj.StartTime = Convert.ToDateTime(row["dProductionStartTime"]);
            if (!Convert.IsDBNull(row["cSuperviser"])) obj.Superviser = Convert.ToString(row["cSuperviser"]);
            if (!Convert.IsDBNull(row["cSuperviserNo"])) obj.SuperviserNo = Convert.ToString(row["cSuperviserNo"]);
            if (!Convert.IsDBNull(row["cChiefof"])) obj.Chief = Convert.ToString(row["cChiefof"]);
            if (!Convert.IsDBNull(row["cChiefofNo"])) obj.ChiefNo = Convert.ToString(row["cChiefofNo"]);
            if (!Convert.IsDBNull(row["cSO"])) obj.SO = Convert.ToString(row["cSO"]);
            if (!Convert.IsDBNull(row["cProcessName"])) obj.ProcessName = Convert.ToString(row["cProcessName"]);
            if (!Convert.IsDBNull(row["dLastReportTime"])) obj.LastReportTime = Convert.ToDateTime(row["dLastReportTime"]);
            if (!Convert.IsDBNull(row["dNextReportTime"])) obj.NextReportTime = Convert.ToDateTime(row["dNextReportTime"]);
            if (!Convert.IsDBNull(row["iPEPlanQtyPer"])) obj.PEPlanQtyPer = Convert.ToString(row["iPEPlanQtyPer"]);
            if (!Convert.IsDBNull(row["iPlanQtyPer"])) obj.PlanQtyPer = Convert.ToString(row["iPlanQtyPer"]);
            if (!Convert.IsDBNull(row["iComplianceRate"])) obj.ComplianceRate = Convert.ToString(row["iComplianceRate"]);
            if (!Convert.IsDBNull(row["iCurrentComplianceRate"])) obj.CurrentComplianceRate = Convert.ToString(row["iCurrentComplianceRate"]);
            return obj;
        }

        static Dictionary<string, DateTime> LoadData()
        {
            FileInfo dataFi = new FileInfo(Path.Combine(Directory.GetCurrentDirectory(), "info.dat"));
            Dictionary<string, DateTime> cache = null;
            if (dataFi.Exists)
            {
                try
                {
                    cache = SerializeFileUtils.DeSerializeObject<Dictionary<string, DateTime>>(dataFi.FullName);
                }
                catch (Exception ex)
                {
                    LogHelper.Error("LoadData Fail!", ex);
                }
            }
            if (cache == null) cache = new Dictionary<string, DateTime>();
            return cache;
        }

        static void SaveData(Dictionary<string, DateTime> cache)
        {
            if (cache == null) return;
            try
            {
                SerializeFileUtils.SerializeObject<Dictionary<string, DateTime>>(cache, Path.Combine(Directory.GetCurrentDirectory(), "info.dat"));
            }
            catch (Exception ex)
            {
                LogHelper.Error("SaveData Fail!", ex);
            }
        }

        static void SendWeiXinNotify(List<WXNotify> wxntfList)
        {
            string token = WeiXinUtils.GetAccessToken(Path.Combine(Directory.GetCurrentDirectory(), "accessToken.json"));
            if (token == null)
            {
                LogHelper.Error("AccessToken Error!", null);
                return;
            }
            if (wxntfList == null || wxntfList.Count == 0) return;
            for (int i = 0; i < wxntfList.Count; i++)
            {
                if (wxntfList[i].WXNews == null || wxntfList[i].ID <= 0) continue;
                LogHelper.Info(wxntfList[i].WXNews.ToJSON());
                string sendPostUrl = WeiXinAccount.Url_SendMessage.Replace("${ACCESS_TOKEN}", token);
                string postResponse = (string.IsNullOrEmpty(wxntfList[i].WXNews.ToUsers) && string.IsNullOrEmpty(wxntfList[i].WXNews.ToParties) && string.IsNullOrEmpty(wxntfList[i].WXNews.ToTags)) ? "" : HttpUtil.HttpPost(sendPostUrl, wxntfList[i].WXNews.ToJSON(), Encoding.UTF8, null);
                wxntfList[i].Status = Constants.WXNotify_Status_SendFail;
                if (!string.IsNullOrEmpty(postResponse))
                {
                    LogHelper.Info(postResponse);
                    JObject o = JObject.Parse(postResponse);
                    wxntfList[i].WXErrCode = o.SelectToken("$.errcode").ToString();
                    wxntfList[i].WXErrMsg = o.SelectToken("$.errmsg").ToString();
                    if ("0".Equals(wxntfList[i].WXErrCode))
                        wxntfList[i].Status = Constants.WXNotify_Status_Sent;
                }
                int result = WXNotifyDAO.Instance.Update(wxntfList[i]);
                if (result > 0) LogHelper.Info("WXNotify Sent " + (wxntfList[i].Status == Constants.WXNotify_Status_Sent?"Success":"Fail") + " & Update Success! ID=" + wxntfList[i].ID);
                else LogHelper.Error("WXNotify Sent " + (wxntfList[i].Status == Constants.WXNotify_Status_Sent ? "Success" : "Fail") + " & Update Fail! ID=" + wxntfList[i].ID, null);
            }
        }
        

        static void SendNewsByWeiXin(List<SendNews> newsList)
        {
            string token = WeiXinUtils.GetAccessToken(Path.Combine(Directory.GetCurrentDirectory(), "accessToken.json"));
            if (token == null)
            {
                LogHelper.Error("AccessToken Error!", null);
                return;
            }
            if (newsList == null || newsList.Count == 0) return;
            for (int i = 0; i < newsList.Count; i++)
            {
                LogHelper.Info(newsList[i].ToJSON());
                string sendPostUrl = WeiXinAccount.Url_SendMessage.Replace("${ACCESS_TOKEN}", token);
                string postResponse = (string.IsNullOrEmpty(newsList[i].ToUsers) && string.IsNullOrEmpty(newsList[i].ToParties) && string.IsNullOrEmpty(newsList[i].ToTags)) ? "" : HttpUtil.HttpPost(sendPostUrl, newsList[i].ToJSON(), Encoding.UTF8, null);
                if (!string.IsNullOrEmpty(postResponse)) LogHelper.Info(postResponse);
            }
        }

        static string ConvertUsers(string user)
        {
            if (string.IsNullOrEmpty(user)) return "";
            //else if (user == "5049342") return "ericchoy";//馮旺英
            //else if (user == "5004550") return "hugohuang";//李建嫦
            //else if (user == "5115944") return "Jimyli";//李蘭枝
            //else if (user == "5060655") return "JojoLi";//韋小玲
            //else if (user == "5041240") return "samhui";//文春梅
            //else if (user == "5030515") return "samdu";//莫翠英
            //else if (user == "5129888") return "kenchen";//李恆
            /*
            else if (user == "5093248") return "janetfeng";//歐玉婷
            else if (user == "5027274") return "JojoLi";//劉從菊
            else if (user == "5260161") return "ericchoy";//陸土鳳
            */
            return user;
        }
    }
}
