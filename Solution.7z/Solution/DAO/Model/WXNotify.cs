using System;
using System.Collections.Generic;
using System.Text;
using WebChatInterface.Class.Model.WXMsg.Send;

namespace Leo.Project.CC.Model
{
    /// <summary>
    /// 微信消息提醒
    /// </summary>
    [Serializable]
    public partial class WXNotify
    {
        #region field

        /// <summary>
        /// 
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// 记录ID
        /// </summary>
        public int CheckID { get; set; }

        /// <summary>
        /// 不达标类型；包括：效率不达标、超时未报数
        /// </summary>
        public string WarnType { get; set; }

        /// <summary>
        /// 提醒对象(督导工号)
        /// </summary>
        public string Target { get; set; }

        /// <summary>
        /// 跟进状态；包括：提醒失败、未跟进、跟进中、已完成
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// 提醒创建时间
        /// </summary>
        public DateTime? CreateTime { get; set; }

        /// <summary>
        /// 最后更新时间
        /// </summary>
        public DateTime? LastUpdate { get; set; }

        /// <summary>
        /// 微信响应码
        /// </summary>
        public string WXErrCode { get; set; }

        /// <summary>
        /// 微信响应信息
        /// </summary>
        public string WXErrMsg { get; set; }

        #endregion

        public SendNews WXNews { get; set; }

        public ProductionCheck CheckInfo { get; set; }
    }
}