using System;
using System.Collections.Generic;
using System.Text;

namespace Leo.Project.CC.Model
{
    /// <summary>
    /// 用户相应记录表
    /// </summary>
    [Serializable]
    public partial class UserResponse
    {
        #region field

        /// <summary>
        /// 用户响应流水号
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// 消息提醒流水号
        /// </summary>
        public int NotifyID { get; set; }

        /// <summary>
        /// 用户ID(对应的微信企业号成员UserID)
        /// </summary>
        public string UserID { get; set; }

        /// <summary>
        /// 设备ID；手机设备号(由微信在安装时随机生成，删除重装会改变，升级不受影响，同一设备上不同的登录账号生成的deviceid也不同) 
        /// </summary>
        public string DeviceID { get; set; }

        /// <summary>
        /// 响应时间
        /// </summary>
        public DateTime? UpdateTime { get; set; }

        /// <summary>
        /// 响应类型，对应跟进状态的：跟进中、已完成
        /// </summary>
        public string Type { get; set; }

        #endregion
    }
}