using System;
using System.Collections.Generic;
using System.Text;

namespace Leo.Project.CC.Model
{
    /// <summary>
    /// 生产线监控记录
    /// </summary>
    [Serializable]
    public partial class ProductionCheck
    {
        #region field

        /// <summary>
        /// 记录ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// 生产线名称
        /// </summary>
        public string LineName { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime? StartTime { get; set; }

        /// <summary>
        /// 班次督导
        /// </summary>
        public string Superviser { get; set; }

        /// <summary>
        /// 班次督导工号
        /// </summary>
        public string SuperviserNo { get; set; }

        /// <summary>
        /// 班次科长
        /// </summary>
        public string Chief { get; set; }

        /// <summary>
        /// 班次科长工号
        /// </summary>
        public string ChiefNo { get; set; }

        /// <summary>
        /// SO Number
        /// </summary>
        public string SO { get; set; }

        /// <summary>
        /// 生产工序
        /// </summary>
        public string ProcessName { get; set; }

        /// <summary>
        /// 报数时间
        /// </summary>
        public DateTime? CheckTime { get; set; }

        /// <summary>
        /// 上次报数时间
        /// </summary>
        public DateTime? LastReportTime { get; set; }

        /// <summary>
        /// 下次报数时间
        /// </summary>
        public DateTime? NextReportTime { get; set; }

        /// <summary>
        /// PD定额
        /// </summary>
        public string PEPlanQtyPer { get; set; }

        /// <summary>
        /// 现场定额
        /// </summary>
        public string PlanQtyPer { get; set; }

        /// <summary>
        /// 达标率
        /// </summary>
        public string ComplianceRate { get; set; }

        /// <summary>
        /// 当前达标率
        /// </summary>
        public string CurrentComplianceRate { get; set; }

        #endregion
    }
}