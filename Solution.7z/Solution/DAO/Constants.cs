﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAO
{
    public class Constants
    {
        public static readonly string WXNotify_Status_Default = "未发送";
        public static readonly string WXNotify_Status_SendFail = "发送失败";
        public static readonly string WXNotify_Status_Sent = "未跟进";
        public static readonly string WXNotify_Status_Following = "跟进中";
        public static readonly string WXNotify_Status_Finished = "已完成";
        public static readonly string WXNotify_Status_Upgrade = "升级处理";
        public static readonly string WXNotify_WarnType_ReportTimeout = "超时未报数";
        public static readonly string WXNotify_WarnType_LowSpeed = "效率不达标";
    }
}
