using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Leo.Project.CC.Model;
using Leo.Project.Common.Helper;
using Leo.Project.Common.Utility;

namespace Leo.Project.CC.DAO
{
	/// <summary>
	/// 微信消息提醒 - DAO类
	/// </summary>
	public partial class WXNotifyDAO
	{
        /// <summary>
        /// 数据库表名
        /// </summary>
		public static readonly string TableName="CC_WXNotify";

        /// <summary>
        /// 将行数据读取转换为指定类型的对象
        /// </summary>
        /// <typeparam name="T">对象类型；必须有无参实例化函数</typeparam>
        /// <param name="row">行数据</param>
        /// <returns>指定类型的对象</returns>
		public static T GetDataObject<T>(DataRow row) where T:new()
		{
            //if (row!=null && typeof(T).IsSubclassOf(typeof(WXNotify)))
            if (row!=null && typeof(WXNotify).IsAssignableFrom(typeof(T)))
            {
                T t = new T();
                WXNotify obj = t as WXNotify;
				if (!Convert.IsDBNull(row["NTF_ID"])) obj.ID = Convert.ToInt32(row["NTF_ID"]);
				if (!Convert.IsDBNull(row["NTF_CheckID"])) obj.CheckID = Convert.ToInt32(row["NTF_CheckID"]);
				if (!Convert.IsDBNull(row["NTF_WarnType"])) obj.WarnType = Convert.ToString(row["NTF_WarnType"]);
				if (!Convert.IsDBNull(row["NTF_Target"])) obj.Target = Convert.ToString(row["NTF_Target"]);
				if (!Convert.IsDBNull(row["NTF_Status"])) obj.Status = Convert.ToString(row["NTF_Status"]);
				if (!Convert.IsDBNull(row["NTF_CreateTime"])) obj.CreateTime = Convert.ToDateTime(row["NTF_CreateTime"]);
				if (!Convert.IsDBNull(row["NTF_LastUpdate"])) obj.LastUpdate = Convert.ToDateTime(row["NTF_LastUpdate"]);
				if (!Convert.IsDBNull(row["NTF_WXErrCode"])) obj.WXErrCode = Convert.ToString(row["NTF_WXErrCode"]);
				if (!Convert.IsDBNull(row["NTF_WXErrMsg"])) obj.WXErrMsg = Convert.ToString(row["NTF_WXErrMsg"]);
				
				return t;
            }
            return default(T);
		}

        protected WXNotifyDAO() { }

        private static WXNotifyDAO _Instance = null;

        private static object _InstanceLock = new object();

        public static WXNotifyDAO Instance
        {
            get
            {
                if (_Instance == null)
                {
                    lock (_InstanceLock)
                    {
                        if (_Instance == null)
                        {
                            _Instance = new WXNotifyDAO();
                        }
                    }
                }
                return _Instance;
            }
        }

		private SqlConnection conn;
        public WXNotifyDAO(SqlConnection connection)
		{
			conn = connection;
		}
		private SqlTransaction trans;
        public WXNotifyDAO(SqlTransaction transaction)
		{
			trans = transaction;
		}

		private SqlConnection getInnerConnection()
		{
			if (conn!=null) return conn;
			if (trans!=null) return trans.Connection;
			return null;
		}


        /// <summary>
        /// 根据PrimaryKey获取对应的记录对象
        /// </summary>
        /// <param name="ID"></param>
        /// <returns>指定PrimaryKey对应的记录对象</returns>
		public WXNotify GetByKey(int ID)
		{
			try
			{
				string strSQL = "SELECT TOP 1 * FROM dbo.CC_WXNotify WHERE NTF_ID=@ID";
				List<SqlParameter> list = new List<SqlParameter>();
				list.Add(SqlHelper.MakeInParam("@ID", SqlDbType.Int, 0, ID));
				DataSet data = trans!=null
					?SqlHelper.ExecuteDataset(trans, strSQL, list.ToArray())
					:SqlHelper.ExecuteDataset(getInnerConnection(), strSQL, list.ToArray());
				if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
				{
					WXNotify obj = GetDataObject<WXNotify>(data.Tables[0].Rows[0]);
					data.Clear();
					return obj;
				}
			}
			catch (Exception e)
			{
				LogHelper.Error(string.Format("GetByKey error: ID={0}", ID), e);
			}
			return null;
		}

        /// <summary>
        /// 删除指定PrimaryKey对应的数据库表记录
        /// </summary>
        /// <param name="ID"></param>
        /// <returns>成功删除的记录数</returns>
		public int DeleteByKey(int ID)
		{
			int rowsAffected = 0;
			try
			{
				string strDeleteSQL = "DELETE dbo.CC_WXNotify WHERE NTF_ID=@ID";
				List<SqlParameter> list = new List<SqlParameter>();
				list.Add(SqlHelper.MakeInParam("@ID", SqlDbType.Int, 0, ID));
				rowsAffected = trans!=null 
					?Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans,strDeleteSQL, list.ToArray()))
					:Convert.ToInt32(SqlHelper.ExecuteNonQuery(getInnerConnection(),strDeleteSQL, list.ToArray()));
			}
			catch (Exception e)
			{
				LogHelper.Error(string.Format("DeleteByKey error: ID={0}", ID), e);
				rowsAffected = -1;
			}
			return rowsAffected;
		}

        /// <summary>
        /// 将数据对象更新至数据库表相应记录
        /// </summary>
        /// <param name="obj">数据对象</param>
        /// <returns>成功更新的记录数</returns>
		public int Update(WXNotify obj)
		{
			if (obj == null) return 0;
			int rowsAffected = 0;
			try
			{
				string strUpdateSQL = "UPDATE dbo.CC_WXNotify SET NTF_CheckID=@CheckID,NTF_WarnType=@WarnType,NTF_Target=@Target,NTF_Status=@Status,NTF_CreateTime=@CreateTime,NTF_LastUpdate=@LastUpdate,NTF_WXErrCode=@WXErrCode,NTF_WXErrMsg=@WXErrMsg WHERE NTF_ID=@ID";
				List<SqlParameter> list = new List<SqlParameter>();
				list.Add(SqlHelper.MakeInParam("@ID", SqlDbType.Int, 0, obj.ID));
				if (obj.CheckID>0)
                    list.Add(SqlHelper.MakeInParam("@CheckID", SqlDbType.Int, 0, obj.CheckID));
                else
                    list.Add(SqlHelper.MakeInParam("@CheckID", SqlDbType.Int, 0, DBNull.Value));
				list.Add(SqlHelper.MakeInParam("@WarnType", SqlDbType.NVarChar, 16, obj.WarnType));
				list.Add(SqlHelper.MakeInParam("@Target", SqlDbType.NVarChar, 16, obj.Target));
				list.Add(SqlHelper.MakeInParam("@Status", SqlDbType.NVarChar, 8, obj.Status));
				list.Add(SqlHelper.MakeInParam("@CreateTime", SqlDbType.DateTime, 0, obj.CreateTime));
				list.Add(SqlHelper.MakeInParam("@LastUpdate", SqlDbType.DateTime, 0, obj.LastUpdate));
				list.Add(SqlHelper.MakeInParam("@WXErrCode", SqlDbType.VarChar, 8, obj.WXErrCode));
				list.Add(SqlHelper.MakeInParam("@WXErrMsg", SqlDbType.NVarChar, 64, obj.WXErrMsg));
				rowsAffected = trans!=null 
					?Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans,strUpdateSQL, list.ToArray()))
					:Convert.ToInt32(SqlHelper.ExecuteNonQuery(getInnerConnection(),strUpdateSQL, list.ToArray()));
			}
			catch (Exception e)
			{
				LogHelper.Error(string.Format("Update WXNotify error: ObjJsonString={0}", JsonUtil<WXNotify>.JsonSerializerObject(obj)), e);
				rowsAffected = -1;
			}
			return rowsAffected;
		}

        /// <summary>
        /// 将数据对象新增至数据库表
        /// </summary>
        /// <param name="obj">数据对象</param>
        /// <returns>成功写入的记录数</returns>
		public int Insert(WXNotify obj)
		{
			if (obj == null) return 0;
			int rowsAffected = 0;
			try
			{
				string strInsertSQL = "INSERT INTO dbo.CC_WXNotify(NTF_CheckID,NTF_WarnType,NTF_Target,NTF_Status,NTF_CreateTime,NTF_LastUpdate,NTF_WXErrCode,NTF_WXErrMsg) VALUES (@CheckID,@WarnType,@Target,@Status,@CreateTime,@LastUpdate,@WXErrCode,@WXErrMsg);SELECT CAST(SCOPE_IDENTITY() AS int);";
				List<SqlParameter> list = new List<SqlParameter>();
				if (obj.CheckID>0)
                    list.Add(SqlHelper.MakeInParam("@CheckID", SqlDbType.Int, 0, obj.CheckID));
                else
                    list.Add(SqlHelper.MakeInParam("@CheckID", SqlDbType.Int, 0, DBNull.Value));
				list.Add(SqlHelper.MakeInParam("@WarnType", SqlDbType.NVarChar, 16, obj.WarnType));
				list.Add(SqlHelper.MakeInParam("@Target", SqlDbType.NVarChar, 16, obj.Target));
				list.Add(SqlHelper.MakeInParam("@Status", SqlDbType.NVarChar, 8, obj.Status));
				list.Add(SqlHelper.MakeInParam("@CreateTime", SqlDbType.DateTime, 0, obj.CreateTime));
				list.Add(SqlHelper.MakeInParam("@LastUpdate", SqlDbType.DateTime, 0, obj.LastUpdate));
				list.Add(SqlHelper.MakeInParam("@WXErrCode", SqlDbType.VarChar, 8, obj.WXErrCode));
				list.Add(SqlHelper.MakeInParam("@WXErrMsg", SqlDbType.NVarChar, 64, obj.WXErrMsg));
				object result = trans!=null
					?SqlHelper.ExecuteScalar(trans, strInsertSQL, list.ToArray())
					:SqlHelper.ExecuteScalar(getInnerConnection(), strInsertSQL, list.ToArray());
                obj.ID = result != null ? (int)result : -1;
				rowsAffected = result != null?1:0;
			}
			catch (Exception e)
			{
				LogHelper.Error(string.Format("Insert WXNotify error: ObjJsonString={0}", JsonUtil<WXNotify>.JsonSerializerObject(obj)), e);
				rowsAffected = -1;
			}
			return rowsAffected;
		}

	}
}