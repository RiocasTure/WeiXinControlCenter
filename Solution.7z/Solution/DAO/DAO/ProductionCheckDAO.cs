using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Leo.Project.CC.Model;
using Leo.Project.Common.Helper;
using Leo.Project.Common.Utility;

namespace Leo.Project.CC.DAO
{
	/// <summary>
	/// 生产线监控记录 - DAO类
	/// </summary>
	public partial class ProductionCheckDAO
	{
        /// <summary>
        /// 数据库表名
        /// </summary>
		public static readonly string TableName="CC_ProductionCheck";

        /// <summary>
        /// 将行数据读取转换为指定类型的对象
        /// </summary>
        /// <typeparam name="T">对象类型；必须有无参实例化函数</typeparam>
        /// <param name="row">行数据</param>
        /// <returns>指定类型的对象</returns>
		public static T GetDataObject<T>(DataRow row) where T:new()
		{
            //if (row!=null && typeof(T).IsSubclassOf(typeof(ProductionCheck)))
            if (row!=null && typeof(ProductionCheck).IsAssignableFrom(typeof(T)))
            {
                T t = new T();
                ProductionCheck obj = t as ProductionCheck;
				if (!Convert.IsDBNull(row["CHK_ID"])) obj.ID = Convert.ToInt32(row["CHK_ID"]);
				if (!Convert.IsDBNull(row["CHK_LineName"])) obj.LineName = Convert.ToString(row["CHK_LineName"]);
				if (!Convert.IsDBNull(row["CHK_StartTime"])) obj.StartTime = Convert.ToDateTime(row["CHK_StartTime"]);
				if (!Convert.IsDBNull(row["CHK_Superviser"])) obj.Superviser = Convert.ToString(row["CHK_Superviser"]);
				if (!Convert.IsDBNull(row["CHK_SuperviserNo"])) obj.SuperviserNo = Convert.ToString(row["CHK_SuperviserNo"]);
				if (!Convert.IsDBNull(row["CHK_Chief"])) obj.Chief = Convert.ToString(row["CHK_Chief"]);
				if (!Convert.IsDBNull(row["CHK_ChiefNo"])) obj.ChiefNo = Convert.ToString(row["CHK_ChiefNo"]);
				if (!Convert.IsDBNull(row["CHK_SO"])) obj.SO = Convert.ToString(row["CHK_SO"]);
				if (!Convert.IsDBNull(row["CHK_ProcessName"])) obj.ProcessName = Convert.ToString(row["CHK_ProcessName"]);
				if (!Convert.IsDBNull(row["CHK_CheckTime"])) obj.CheckTime = Convert.ToDateTime(row["CHK_CheckTime"]);
				if (!Convert.IsDBNull(row["CHK_LastReportTime"])) obj.LastReportTime = Convert.ToDateTime(row["CHK_LastReportTime"]);
				if (!Convert.IsDBNull(row["CHK_NextReportTime"])) obj.NextReportTime = Convert.ToDateTime(row["CHK_NextReportTime"]);
				if (!Convert.IsDBNull(row["CHK_PEPlanQtyPer"])) obj.PEPlanQtyPer = Convert.ToString(row["CHK_PEPlanQtyPer"]);
				if (!Convert.IsDBNull(row["CHK_PlanQtyPer"])) obj.PlanQtyPer = Convert.ToString(row["CHK_PlanQtyPer"]);
				if (!Convert.IsDBNull(row["CHK_ComplianceRate"])) obj.ComplianceRate = Convert.ToString(row["CHK_ComplianceRate"]);
				if (!Convert.IsDBNull(row["CHK_CurrentComplianceRate"])) obj.CurrentComplianceRate = Convert.ToString(row["CHK_CurrentComplianceRate"]);
				
				return t;
            }
            return default(T);
		}

        protected ProductionCheckDAO() { }

        private static ProductionCheckDAO _Instance = null;

        private static object _InstanceLock = new object();

        public static ProductionCheckDAO Instance
        {
            get
            {
                if (_Instance == null)
                {
                    lock (_InstanceLock)
                    {
                        if (_Instance == null)
                        {
                            _Instance = new ProductionCheckDAO();
                        }
                    }
                }
                return _Instance;
            }
        }

		private SqlConnection conn;
        public ProductionCheckDAO(SqlConnection connection)
		{
			conn = connection;
		}
		private SqlTransaction trans;
        public ProductionCheckDAO(SqlTransaction transaction)
		{
			trans = transaction;
		}

		private SqlConnection getInnerConnection()
		{
			if (conn!=null) return conn;
			if (trans!=null) return trans.Connection;
			return null;
		}


        /// <summary>
        /// 根据PrimaryKey获取对应的记录对象
        /// </summary>
        /// <param name="ID">记录ID</param>
        /// <returns>指定PrimaryKey对应的记录对象</returns>
		public ProductionCheck GetByKey(int ID)
		{
			try
			{
				string strSQL = "SELECT TOP 1 * FROM dbo.CC_ProductionCheck WHERE CHK_ID=@ID";
				List<SqlParameter> list = new List<SqlParameter>();
				list.Add(SqlHelper.MakeInParam("@ID", SqlDbType.Int, 0, ID));
				DataSet data = trans!=null
					?SqlHelper.ExecuteDataset(trans, strSQL, list.ToArray())
					:SqlHelper.ExecuteDataset(getInnerConnection(), strSQL, list.ToArray());
				if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
				{
					ProductionCheck obj = GetDataObject<ProductionCheck>(data.Tables[0].Rows[0]);
					data.Clear();
					return obj;
				}
			}
			catch (Exception e)
			{
				LogHelper.Error(string.Format("GetByKey error: ID={0}", ID), e);
			}
			return null;
		}

        /// <summary>
        /// 删除指定PrimaryKey对应的数据库表记录
        /// </summary>
        /// <param name="ID">记录ID</param>
        /// <returns>成功删除的记录数</returns>
		public int DeleteByKey(int ID)
		{
			int rowsAffected = 0;
			try
			{
				string strDeleteSQL = "DELETE dbo.CC_ProductionCheck WHERE CHK_ID=@ID";
				List<SqlParameter> list = new List<SqlParameter>();
				list.Add(SqlHelper.MakeInParam("@ID", SqlDbType.Int, 0, ID));
				rowsAffected = trans!=null 
					?Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans,strDeleteSQL, list.ToArray()))
					:Convert.ToInt32(SqlHelper.ExecuteNonQuery(getInnerConnection(),strDeleteSQL, list.ToArray()));
			}
			catch (Exception e)
			{
				LogHelper.Error(string.Format("DeleteByKey error: ID={0}", ID), e);
				rowsAffected = -1;
			}
			return rowsAffected;
		}

        /// <summary>
        /// 将数据对象更新至数据库表相应记录
        /// </summary>
        /// <param name="obj">数据对象</param>
        /// <returns>成功更新的记录数</returns>
		public int Update(ProductionCheck obj)
		{
			if (obj == null) return 0;
			int rowsAffected = 0;
			try
			{
				string strUpdateSQL = "UPDATE dbo.CC_ProductionCheck SET CHK_LineName=@LineName,CHK_StartTime=@StartTime,CHK_Superviser=@Superviser,CHK_SuperviserNo=@SuperviserNo,CHK_Chief=@Chief,CHK_ChiefNo=@ChiefNo,CHK_SO=@SO,CHK_ProcessName=@ProcessName,CHK_CheckTime=@CheckTime,CHK_LastReportTime=@LastReportTime,CHK_NextReportTime=@NextReportTime,CHK_PEPlanQtyPer=@PEPlanQtyPer,CHK_PlanQtyPer=@PlanQtyPer,CHK_ComplianceRate=@ComplianceRate,CHK_CurrentComplianceRate=@CurrentComplianceRate WHERE CHK_ID=@ID";
				List<SqlParameter> list = new List<SqlParameter>();
				list.Add(SqlHelper.MakeInParam("@ID", SqlDbType.Int, 0, obj.ID));
				list.Add(SqlHelper.MakeInParam("@LineName", SqlDbType.NVarChar, 32, obj.LineName));
				list.Add(SqlHelper.MakeInParam("@StartTime", SqlDbType.DateTime, 0, obj.StartTime));
				list.Add(SqlHelper.MakeInParam("@Superviser", SqlDbType.NVarChar, 16, obj.Superviser));
				list.Add(SqlHelper.MakeInParam("@SuperviserNo", SqlDbType.VarChar, 8, obj.SuperviserNo));
				list.Add(SqlHelper.MakeInParam("@Chief", SqlDbType.NVarChar, 16, obj.Chief));
				list.Add(SqlHelper.MakeInParam("@ChiefNo", SqlDbType.VarChar, 8, obj.ChiefNo));
				list.Add(SqlHelper.MakeInParam("@SO", SqlDbType.VarChar, 16, obj.SO));
				list.Add(SqlHelper.MakeInParam("@ProcessName", SqlDbType.NVarChar, 32, obj.ProcessName));
				list.Add(SqlHelper.MakeInParam("@CheckTime", SqlDbType.DateTime, 0, obj.CheckTime));
				list.Add(SqlHelper.MakeInParam("@LastReportTime", SqlDbType.DateTime, 0, obj.LastReportTime));
				list.Add(SqlHelper.MakeInParam("@NextReportTime", SqlDbType.DateTime, 0, obj.NextReportTime));
				list.Add(SqlHelper.MakeInParam("@PEPlanQtyPer", SqlDbType.NVarChar, 32, obj.PEPlanQtyPer));
				list.Add(SqlHelper.MakeInParam("@PlanQtyPer", SqlDbType.NVarChar, 32, obj.PlanQtyPer));
				list.Add(SqlHelper.MakeInParam("@ComplianceRate", SqlDbType.VarChar, 16, obj.ComplianceRate));
				list.Add(SqlHelper.MakeInParam("@CurrentComplianceRate", SqlDbType.VarChar, 16, obj.CurrentComplianceRate));
				rowsAffected = trans!=null 
					?Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans,strUpdateSQL, list.ToArray()))
					:Convert.ToInt32(SqlHelper.ExecuteNonQuery(getInnerConnection(),strUpdateSQL, list.ToArray()));
			}
			catch (Exception e)
			{
				LogHelper.Error(string.Format("Update ProductionCheck error: ObjJsonString={0}", JsonUtil<ProductionCheck>.JsonSerializerObject(obj)), e);
				rowsAffected = -1;
			}
			return rowsAffected;
		}

        /// <summary>
        /// 将数据对象新增至数据库表
        /// </summary>
        /// <param name="obj">数据对象</param>
        /// <returns>成功写入的记录数</returns>
		public int Insert(ProductionCheck obj)
		{
			if (obj == null) return 0;
			int rowsAffected = 0;
			try
			{
				string strInsertSQL = "INSERT INTO dbo.CC_ProductionCheck(CHK_LineName,CHK_StartTime,CHK_Superviser,CHK_SuperviserNo,CHK_Chief,CHK_ChiefNo,CHK_SO,CHK_ProcessName,CHK_CheckTime,CHK_LastReportTime,CHK_NextReportTime,CHK_PEPlanQtyPer,CHK_PlanQtyPer,CHK_ComplianceRate,CHK_CurrentComplianceRate) VALUES (@LineName,@StartTime,@Superviser,@SuperviserNo,@Chief,@ChiefNo,@SO,@ProcessName,@CheckTime,@LastReportTime,@NextReportTime,@PEPlanQtyPer,@PlanQtyPer,@ComplianceRate,@CurrentComplianceRate);SELECT CAST(SCOPE_IDENTITY() AS int);";
				List<SqlParameter> list = new List<SqlParameter>();
				list.Add(SqlHelper.MakeInParam("@LineName", SqlDbType.NVarChar, 32, obj.LineName));
				list.Add(SqlHelper.MakeInParam("@StartTime", SqlDbType.DateTime, 0, obj.StartTime));
				list.Add(SqlHelper.MakeInParam("@Superviser", SqlDbType.NVarChar, 16, obj.Superviser));
				list.Add(SqlHelper.MakeInParam("@SuperviserNo", SqlDbType.VarChar, 8, obj.SuperviserNo));
				list.Add(SqlHelper.MakeInParam("@Chief", SqlDbType.NVarChar, 16, obj.Chief));
				list.Add(SqlHelper.MakeInParam("@ChiefNo", SqlDbType.VarChar, 8, obj.ChiefNo));
				list.Add(SqlHelper.MakeInParam("@SO", SqlDbType.VarChar, 16, obj.SO));
				list.Add(SqlHelper.MakeInParam("@ProcessName", SqlDbType.NVarChar, 32, obj.ProcessName));
				list.Add(SqlHelper.MakeInParam("@CheckTime", SqlDbType.DateTime, 0, obj.CheckTime));
				list.Add(SqlHelper.MakeInParam("@LastReportTime", SqlDbType.DateTime, 0, obj.LastReportTime));
				list.Add(SqlHelper.MakeInParam("@NextReportTime", SqlDbType.DateTime, 0, obj.NextReportTime));
				list.Add(SqlHelper.MakeInParam("@PEPlanQtyPer", SqlDbType.NVarChar, 32, obj.PEPlanQtyPer));
				list.Add(SqlHelper.MakeInParam("@PlanQtyPer", SqlDbType.NVarChar, 32, obj.PlanQtyPer));
				list.Add(SqlHelper.MakeInParam("@ComplianceRate", SqlDbType.VarChar, 16, obj.ComplianceRate));
				list.Add(SqlHelper.MakeInParam("@CurrentComplianceRate", SqlDbType.VarChar, 16, obj.CurrentComplianceRate));
				object result = trans!=null
					?SqlHelper.ExecuteScalar(trans, strInsertSQL, list.ToArray())
					:SqlHelper.ExecuteScalar(getInnerConnection(), strInsertSQL, list.ToArray());
                obj.ID = result != null ? (int)result : -1;
				rowsAffected = result != null?1:0;
			}
			catch (Exception e)
			{
				LogHelper.Error(string.Format("Insert ProductionCheck error: ObjJsonString={0}", JsonUtil<ProductionCheck>.JsonSerializerObject(obj)), e);
				rowsAffected = -1;
			}
			return rowsAffected;
		}

	}
}