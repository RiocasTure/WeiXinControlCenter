using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Leo.Project.CC.Model;
using Leo.Project.Common.Helper;
using Leo.Project.Common.Utility;

namespace Leo.Project.CC.DAO
{
	/// <summary>
	/// 用户相应记录表 - DAO类
	/// </summary>
	public partial class UserResponseDAO
	{
        /// <summary>
        /// 数据库表名
        /// </summary>
		public static readonly string TableName="CC_UserResponse";

        /// <summary>
        /// 将行数据读取转换为指定类型的对象
        /// </summary>
        /// <typeparam name="T">对象类型；必须有无参实例化函数</typeparam>
        /// <param name="row">行数据</param>
        /// <returns>指定类型的对象</returns>
		public static T GetDataObject<T>(DataRow row) where T:new()
		{
            //if (row!=null && typeof(T).IsSubclassOf(typeof(UserResponse)))
            if (row!=null && typeof(UserResponse).IsAssignableFrom(typeof(T)))
            {
                T t = new T();
                UserResponse obj = t as UserResponse;
				if (!Convert.IsDBNull(row["RSP_ID"])) obj.ID = Convert.ToInt32(row["RSP_ID"]);
				if (!Convert.IsDBNull(row["RSP_NotifyID"])) obj.NotifyID = Convert.ToInt32(row["RSP_NotifyID"]);
				if (!Convert.IsDBNull(row["RSP_UserID"])) obj.UserID = Convert.ToString(row["RSP_UserID"]);
				if (!Convert.IsDBNull(row["RSP_DeviceID"])) obj.DeviceID = Convert.ToString(row["RSP_DeviceID"]);
				if (!Convert.IsDBNull(row["RSP_UpdateTime"])) obj.UpdateTime = Convert.ToDateTime(row["RSP_UpdateTime"]);
				if (!Convert.IsDBNull(row["RSP_Type"])) obj.Type = Convert.ToString(row["RSP_Type"]);
				
				return t;
            }
            return default(T);
		}

        protected UserResponseDAO() { }

        private static UserResponseDAO _Instance = null;

        private static object _InstanceLock = new object();

        public static UserResponseDAO Instance
        {
            get
            {
                if (_Instance == null)
                {
                    lock (_InstanceLock)
                    {
                        if (_Instance == null)
                        {
                            _Instance = new UserResponseDAO();
                        }
                    }
                }
                return _Instance;
            }
        }

		private SqlConnection conn;
        public UserResponseDAO(SqlConnection connection)
		{
			conn = connection;
		}
		private SqlTransaction trans;
        public UserResponseDAO(SqlTransaction transaction)
		{
			trans = transaction;
		}

		private SqlConnection getInnerConnection()
		{
			if (conn!=null) return conn;
			if (trans!=null) return trans.Connection;
			return null;
		}


        /// <summary>
        /// 根据PrimaryKey获取对应的记录对象
        /// </summary>
        /// <param name="ID">用户响应流水号</param>
        /// <returns>指定PrimaryKey对应的记录对象</returns>
		public UserResponse GetByKey(int ID)
		{
			try
			{
				string strSQL = "SELECT TOP 1 * FROM dbo.CC_UserResponse WHERE RSP_ID=@ID";
				List<SqlParameter> list = new List<SqlParameter>();
				list.Add(SqlHelper.MakeInParam("@ID", SqlDbType.Int, 0, ID));
				DataSet data = trans!=null
					?SqlHelper.ExecuteDataset(trans, strSQL, list.ToArray())
					:SqlHelper.ExecuteDataset(getInnerConnection(), strSQL, list.ToArray());
				if (data.Tables.Count > 0 && data.Tables[0].Rows.Count > 0)
				{
					UserResponse obj = GetDataObject<UserResponse>(data.Tables[0].Rows[0]);
					data.Clear();
					return obj;
				}
			}
			catch (Exception e)
			{
				LogHelper.Error(string.Format("GetByKey error: ID={0}", ID), e);
			}
			return null;
		}

        /// <summary>
        /// 删除指定PrimaryKey对应的数据库表记录
        /// </summary>
        /// <param name="ID">用户响应流水号</param>
        /// <returns>成功删除的记录数</returns>
		public int DeleteByKey(int ID)
		{
			int rowsAffected = 0;
			try
			{
				string strDeleteSQL = "DELETE dbo.CC_UserResponse WHERE RSP_ID=@ID";
				List<SqlParameter> list = new List<SqlParameter>();
				list.Add(SqlHelper.MakeInParam("@ID", SqlDbType.Int, 0, ID));
				rowsAffected = trans!=null 
					?Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans,strDeleteSQL, list.ToArray()))
					:Convert.ToInt32(SqlHelper.ExecuteNonQuery(getInnerConnection(),strDeleteSQL, list.ToArray()));
			}
			catch (Exception e)
			{
				LogHelper.Error(string.Format("DeleteByKey error: ID={0}", ID), e);
				rowsAffected = -1;
			}
			return rowsAffected;
		}

        /// <summary>
        /// 将数据对象更新至数据库表相应记录
        /// </summary>
        /// <param name="obj">数据对象</param>
        /// <returns>成功更新的记录数</returns>
		public int Update(UserResponse obj)
		{
			if (obj == null) return 0;
			int rowsAffected = 0;
			try
			{
				string strUpdateSQL = "UPDATE dbo.CC_UserResponse SET RSP_NotifyID=@NotifyID,RSP_UserID=@UserID,RSP_DeviceID=@DeviceID,RSP_UpdateTime=@UpdateTime,RSP_Type=@Type WHERE RSP_ID=@ID";
				List<SqlParameter> list = new List<SqlParameter>();
				list.Add(SqlHelper.MakeInParam("@ID", SqlDbType.Int, 0, obj.ID));
				if (obj.NotifyID>0)
                    list.Add(SqlHelper.MakeInParam("@NotifyID", SqlDbType.Int, 0, obj.NotifyID));
                else
                    list.Add(SqlHelper.MakeInParam("@NotifyID", SqlDbType.Int, 0, DBNull.Value));
				list.Add(SqlHelper.MakeInParam("@UserID", SqlDbType.NVarChar, 32, obj.UserID));
				list.Add(SqlHelper.MakeInParam("@DeviceID", SqlDbType.VarChar, 32, obj.DeviceID));
				list.Add(SqlHelper.MakeInParam("@UpdateTime", SqlDbType.DateTime, 0, obj.UpdateTime));
				list.Add(SqlHelper.MakeInParam("@Type", SqlDbType.NVarChar, 16, obj.Type));
				rowsAffected = trans!=null 
					?Convert.ToInt32(SqlHelper.ExecuteNonQuery(trans,strUpdateSQL, list.ToArray()))
					:Convert.ToInt32(SqlHelper.ExecuteNonQuery(getInnerConnection(),strUpdateSQL, list.ToArray()));
			}
			catch (Exception e)
			{
				LogHelper.Error(string.Format("Update UserResponse error: ObjJsonString={0}", JsonUtil<UserResponse>.JsonSerializerObject(obj)), e);
				rowsAffected = -1;
			}
			return rowsAffected;
		}

        /// <summary>
        /// 将数据对象新增至数据库表
        /// </summary>
        /// <param name="obj">数据对象</param>
        /// <returns>成功写入的记录数</returns>
		public int Insert(UserResponse obj)
		{
			if (obj == null) return 0;
			int rowsAffected = 0;
			try
			{
				string strInsertSQL = "INSERT INTO dbo.CC_UserResponse(RSP_NotifyID,RSP_UserID,RSP_DeviceID,RSP_UpdateTime,RSP_Type) VALUES (@NotifyID,@UserID,@DeviceID,@UpdateTime,@Type);SELECT CAST(SCOPE_IDENTITY() AS int);";
				List<SqlParameter> list = new List<SqlParameter>();
				if (obj.NotifyID>0)
                    list.Add(SqlHelper.MakeInParam("@NotifyID", SqlDbType.Int, 0, obj.NotifyID));
                else
                    list.Add(SqlHelper.MakeInParam("@NotifyID", SqlDbType.Int, 0, DBNull.Value));
				list.Add(SqlHelper.MakeInParam("@UserID", SqlDbType.NVarChar, 32, obj.UserID));
				list.Add(SqlHelper.MakeInParam("@DeviceID", SqlDbType.VarChar, 32, obj.DeviceID));
				list.Add(SqlHelper.MakeInParam("@UpdateTime", SqlDbType.DateTime, 0, obj.UpdateTime));
				list.Add(SqlHelper.MakeInParam("@Type", SqlDbType.NVarChar, 16, obj.Type));
				object result = trans!=null
					?SqlHelper.ExecuteScalar(trans, strInsertSQL, list.ToArray())
					:SqlHelper.ExecuteScalar(getInnerConnection(), strInsertSQL, list.ToArray());
                obj.ID = result != null ? (int)result : -1;
				rowsAffected = result != null?1:0;
			}
			catch (Exception e)
			{
				LogHelper.Error(string.Format("Insert UserResponse error: ObjJsonString={0}", JsonUtil<UserResponse>.JsonSerializerObject(obj)), e);
				rowsAffected = -1;
			}
			return rowsAffected;
		}

	}
}