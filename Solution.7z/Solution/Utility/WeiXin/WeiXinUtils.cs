﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json.Linq;
using WebChatInterface.Class.Tencent;
using System.Text;
using Tools;
using System.IO;
using Leo.Project.Common.Utility;
using Leo.Project.Common.Helper;

namespace LEO.Common.Tools.WeiXin
{
    public class WeiXinUtils
    {
        public static string GetAccessToken(string tokenFile)
        {
            JObject o = null;
            JToken timestamp = null;
            JToken expireSecond = null;
            JToken accessToken = null;
            //string tokenFile = HttpContext.Current.Server.MapPath("~/accessToken.json");
            string tokenJson = ReadTextFromFile(tokenFile);
            if (tokenJson != null)
            {
                o = JObject.Parse(tokenJson);
                accessToken = o.SelectToken("$.access_token");
                timestamp = o.SelectToken("$.last_access_time");
                expireSecond = o.SelectToken("$.expires_in");
            }
            if (accessToken != null && timestamp != null && expireSecond != null)
            {
                long ts = long.Parse(timestamp.ToString());
                long expire = int.Parse(expireSecond.ToString()) * 1000;
                long now = DateTimeUtil.CurrentMillis;
                if (ts + expire > now + 2000) //滞后2秒
                {
                    //如果上次获取的未过期则直接返回
                    return accessToken.ToString();
                }
            }

            //到服务器获取
            string getUrl = WeiXinAccount.Url_GetToken;
            string getResponse = null;

            try
            {
                getResponse = HttpUtil.HttpGet(getUrl, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                LogHelper.Error("Http Get Error:\r\n" + getUrl, ex);
                return null;
            }

            o = JObject.Parse(getResponse);
            if (o == null) return null;

            accessToken = o.SelectToken("$.access_token");
            timestamp = o.SelectToken("$.last_access_time");
            if (accessToken != null)
            {
                if (timestamp != null) timestamp.Remove();
                timestamp = JToken.Parse("" + DateTimeUtil.CurrentMillis + "");
                o.Add("last_access_time", timestamp);
            }
            WriteTextToFile(tokenFile, o.ToString());
            if (accessToken != null) return accessToken.ToString();
            return null;
        }

        public static string ReadTextFromFile(string path)
        {
            if (!File.Exists(path))
            {
                return null;
            }
            StringBuilder json = new StringBuilder();
            //异常检测开始
            try
            {
                StreamReader sr = new StreamReader(path, Encoding.UTF8);
                //使用StreamReader类来读取文件
                sr.BaseStream.Seek(0, SeekOrigin.Begin);
                String line;
                while ((line = sr.ReadLine()) != null)
                {
                    if (json.Length > 0) json.Append('\r').Append('\n');
                    json.Append(line);
                }
                //关闭此StreamReader对象
                sr.Close();
            }
            catch
            {
            }
            //异常检测结束
            return json.ToString();
        }
        /// <summary>
        /// 將獲取到的accesstoken字符串寫到accesstoken.json文件中
        /// </summary>
        /// <param name="filepath">accesstoken.json文件路徑</param>
        /// <param name="text">從企業號服務器獲取到的accesstoken字符串</param>
        public static void WriteTextToFile(string filepath, string text)
        {
            StreamWriter strWriter = new StreamWriter(filepath, false, Encoding.UTF8);//overwrite, not append
            strWriter.WriteLine(text);
            strWriter.Close();
        }

        public static void LogJson(string json, string logJsonFile)
        {
            DateTime now = DateTime.Now;
            //string logJsonFile = HttpContext.Current.Server.MapPath("~/Log/jsons/"+"info-" + now.ToString("yyyyMMdd") + ".log");
            StreamWriter strWriter = new StreamWriter(logJsonFile, true, Encoding.UTF8);//append, not overwrite
            strWriter.WriteLine("=======================[" + now.ToString("yyyy-MM-dd hh:mm:ss") + "]=======================");
            strWriter.WriteLine(json);
            strWriter.WriteLine();
            strWriter.Close();
        }

    }
}
