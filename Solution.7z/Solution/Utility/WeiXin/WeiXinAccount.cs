﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebChatInterface.Class.Tencent
{
    public class WeiXinAccount
    {
        public static readonly string Token = "pg1gYiqs3HfBxW8w7cegzf5U";
        public static readonly string EncodingAESKey = "PsMMMgG1XKQajMefYvsmnXFvgehOOwcVNGfyJ99czpN";
        public static readonly int DefaultAppAgentId = 2;

        /*
         * 雅圖仕應用中心（企業號）
         */
        public static readonly string CorpID = "wxa4f76c4bc0634433";//雅圖仕企業號
        public static readonly string AdminSecret = "1HAMtT_FOQhK0xmSWUgSOE5UMiH1Yel7RbO88oYIpN6IfFh4toiZxK84mwkx-HGD";

        //發送企業號消息的API
        public static readonly string Url_SendMessage = "https://qyapi.weixin.qq.com/cgi-bin/message/send?access_token=${ACCESS_TOKEN}";
        public static readonly string Url_CreateMenu = "https://qyapi.weixin.qq.com/cgi-bin/menu/create?access_token=${ACCESS_TOKEN}&agentid=${AGENTID}";
        //獲取accessTokende的鏈接，由corpID+corpsecret向指定URL獲取，獲得的accesstoken有效期為２個小時，獲取后保存在accesstoken.json文件中，一旦過期則重新由此鏈接獲取
        public static readonly string Url_GetToken = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=" + WeiXinAccount.CorpID + "&corpsecret=" + WeiXinAccount.AdminSecret;
    }
}
