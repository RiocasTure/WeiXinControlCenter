﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebChatInterface.Class.Model.WXMsg.Send
{
    public abstract class BaseSend
    {
        public BaseSend(string msgType)
        {
            this.MsgType = msgType;
        }

        public string ToJSON()
        {
            return "{"+Environment.NewLine+
                "   \"touser\":\"" + ((string.IsNullOrEmpty(ToUsers) && string.IsNullOrEmpty(ToParties) && string.IsNullOrEmpty(ToTags)) ? "@All" : (string.IsNullOrEmpty(ToUsers)?"":ToUsers)) + "\"," + Environment.NewLine +
                "   \"toparty\":\"" + (string.IsNullOrEmpty(ToParties) ? "" : ToParties) + "\"," + Environment.NewLine +
                "   \"totag\":\"" + (string.IsNullOrEmpty(ToTags) ? "" : ToTags) + "\"," + Environment.NewLine +
                "   \"msgtype\":\"" + MsgType + "\"," + Environment.NewLine +
                "   \"agentid\":\"" + AgentID + "\"," + Environment.NewLine +
                "   \"" + MsgType + "\": {" + Environment.NewLine + BodyJSON + Environment.NewLine + "   }" + SafeJSON + Environment.NewLine + "}";
        }

        public abstract string BodyJSON
        {
            get;
        }
        public virtual string SafeJSON
        {
            get
            {
                return "," + Environment.NewLine + "   \"safe\":\"" + (IsSafe ? "1" : "0") + "\"";
            }
        }
        /// <summary>
        /// 成员ID列表（消息接收者，多个接收者用‘|’分隔，最多支持1000个）。特殊情况：指定为@all，则向关注该企业应用的全部成员发送 
        /// </summary>
        public string ToUsers { get; set; }
        /// <summary>
        /// 部门ID列表，多个接收者用‘|’分隔，最多支持100个。当touser为@all时忽略本参数 
        /// </summary>
        public string ToParties { get; set; }
        /// <summary>
        /// 标签ID列表，多个接收者用‘|’分隔。当touser为@all时忽略本参数 
        /// </summary>
        public string ToTags { get; set; }
        /// <summary>
        /// 消息类型，此时固定为：news 
        /// </summary>
        public string MsgType { get; set; }
        /// <summary>
        /// 企业应用的id，整型。可在应用的设置页面查看 
        /// </summary>
        public string AgentID { get; set; }
        public string Content;
        public bool IsSafe;
    }
}
