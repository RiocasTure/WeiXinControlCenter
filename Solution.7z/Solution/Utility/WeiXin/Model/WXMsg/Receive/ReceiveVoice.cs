﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

namespace WebChatInterface.Class.Model.WXMsg.Receive
{
    public class ReceiveVoice:BaseReceive
    {
        public ReceiveVoice()
            : base("voice")
        {
        }
        public ReceiveVoice(XmlNode node)
            : base(node)
        {
            this.MediaId = node["MediaId"].InnerText;
            this.Format = node["Format"].InnerText;
            //this.MsgType = "voice";//node["MsgType"].InnerText;
        }
        /// <summary>
        /// 语音媒体文件id，可以调用获取媒体文件接口拉取数据
        /// </summary>
        public string MediaId { get; set; }
        /// <summary>
        /// 语音格式，如amr，speex等 
        /// </summary>
        public string Format { get; set; }
    }
}
