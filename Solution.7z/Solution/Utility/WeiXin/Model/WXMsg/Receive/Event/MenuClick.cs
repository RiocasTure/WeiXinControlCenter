﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

namespace WebChatInterface.Class.Model.WXMsg.Receive.Event
{
    public class MenuClick : BaseEvent
    {
        public MenuClick()
            : base("CLICK")
        {
        }
        public MenuClick(XmlNode node)
            : base(node)
        {
            this.EventKey = node["EventKey"].InnerText;
        }

        /// <summary>
        /// VIEW(点击菜单跳转链接 - EventKey 事件KEY值，设置的跳转URL )
        /// </summary>
        public string EventKey { get; set; }
    }
}
