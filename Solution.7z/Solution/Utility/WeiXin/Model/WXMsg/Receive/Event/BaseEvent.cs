﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

namespace WebChatInterface.Class.Model.WXMsg.Receive.Event
{
    public class BaseEvent:BaseReceive
    {
        public BaseEvent()
            : base("event")
        {
        }
        public BaseEvent(string eventVal)
            : base("event")
        {
            this.Event = eventVal;
        }
        public BaseEvent(XmlNode node)
            : base(node)
        {
            this.Event = node["Event"].InnerText;
            //this.MsgType = "event";//node["MsgType"].InnerText;
        }
        /// <summary>
        /// 事件类型
        /// 分为：
        /// subscribe(订阅)
        /// unsubscribe(取消订阅)
        /// LOCATION(上报地理位置)
        /// CLICK(菜单点击-弹出子菜单事件不上报 - EventKey 事件KEY值，与自定义菜单接口中KEY值对应 )
        /// VIEW(点击菜单跳转链接 - EventKey 事件KEY值，设置的跳转URL )
        /// enter_agent(成员进入应用的事件推送 - 本事件在成员进入企业号的应用时触发，如果企业需要接收此事件，请打开应用回调模式中的相应开关。 )
        /// </summary>
        public string Event { get; set; }
    }
}
