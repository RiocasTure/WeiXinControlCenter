﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

namespace WebChatInterface.Class.Model.WXMsg.Receive.Event
{
    public class ViewUrl : BaseEvent
    {
        public ViewUrl()
            : base("VIEW")
        {
        }
        public ViewUrl(XmlNode node)
            : base(node)
        {
            this.EventKey = node["EventKey"].InnerText;
        }

        /// <summary>
        /// 事件KEY值，与自定义菜单接口中KEY值对应 
        /// </summary>
        public string EventKey { get; set; }
    }
}
