﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

namespace WebChatInterface.Class.Model.WXMsg.Receive.Event
{
    public class EnterAgent:BaseEvent
    {
        public EnterAgent()
            : base("enter_agent")
        {
        }
        public EnterAgent(XmlNode node)
            : base(node)
        {
            this.EventKey = node["EventKey"].InnerText;
        }

        /// <summary>
        /// 事件KEY值，此事件该值为空
        /// </summary>
        public string EventKey { get; set; }
    }
}
