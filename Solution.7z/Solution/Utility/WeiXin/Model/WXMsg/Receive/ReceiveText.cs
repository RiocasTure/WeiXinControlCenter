﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

namespace WebChatInterface.Class.Model.WXMsg.Receive
{
    public class ReceiveText:BaseReceive
    {
        public ReceiveText()
            : base("text")
        {
        }
        public ReceiveText(XmlNode node)
            : base(node)
        {
            this.Content = node["Content"].InnerText;
            //this.MsgType = "text";//node["MsgType"].InnerText;
        }

        /// <summary>
        /// 文本消息内容 
        /// </summary>
        public string Content { get; set; }
    }
}
