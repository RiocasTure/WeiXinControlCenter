﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

namespace WebChatInterface.Class.Model.WXMsg.Receive
{
    public class ReceiveImage : BaseReceive
    {
        public ReceiveImage()
            : base("image")
        {
        }
        public ReceiveImage(XmlNode node)
            : base(node)
        {
            this.PicUrl = node["PicUrl"].InnerText;
            this.MediaId = node["MediaId"].InnerText;
            //this.MsgType = "image";//node["MsgType"].InnerText;
        }
        /// <summary>
        /// 图片链接
        /// </summary>
        public string PicUrl { get; set; }
        /// <summary>
        /// 图片媒体文件id，可以调用获取媒体文件接口拉取数据 
        /// </summary>
        public string MediaId { get; set; }
    }
}
