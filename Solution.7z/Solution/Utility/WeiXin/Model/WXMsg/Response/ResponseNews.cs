﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebChatInterface.Class.Model.WXMsg.Response
{
    public class ResponseNews:BaseResponse
    {
        public ResponseNews()
            : base("news")
        {
        }

        public override string ResponseXML()
        {
            //在CDATA内部的所有内容都会被解析器忽略
            string xml = "<ArticleCount>" + articles.Count + "</ArticleCount><Articles>";
            for (int i = 0; i < articles.Count; i++)
            {
                xml += "<item><Title><![CDATA[" + articles[i].Title + "]]></Title>" +
                    "<Description><![CDATA[" + articles[i].Description + "]]></Description>" +
                    "<PicUrl><![CDATA[" + articles[i].PicUrl + "]]></PicUrl>" +
                    "<Url><![CDATA[" + articles[i].Url + "]]></Url></item>";
            }
            xml += "</Articles>";
            return xml;
        }

        /// <summary>
        /// 图文条数，默认第一条为大图。图文数不能超过10，否则将会无响应 
        /// </summary>
        public List<NewsItem> Articles
        {
            get { return articles; }
        }
        public void AddNewsItem(string Title, string Description, string PicUrl, string Url)
        {
            NewsItem article = new NewsItem();
            article.Title = Title;
            article.Description = Description;
            article.PicUrl = PicUrl;
            article.Url = Url;
            articles.Add(article);
        }
        private List<NewsItem> articles = new List<NewsItem>();
    }
    public class NewsItem
    {
        public string Title { get; set; } //图文消息标题 
        public string Description { get; set; } //图文消息描述 
        public string PicUrl { get; set; } //图片链接，支持JPG、PNG格式，较好的效果为大图360*200，小图200*200 
        public string Url { get; set; } //点击图文消息跳转链接
    }
}
