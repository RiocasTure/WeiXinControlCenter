﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebChatInterface.Class.Model.WXMsg.Response
{
    public class ResponseVoice:BaseResponse
    {
        public ResponseVoice()
            : base("voice")
        {
        }

        public override string ResponseXML()
        {
            //在CDATA内部的所有内容都会被解析器忽略
            return "<Voice><MediaId><![CDATA[" + MediaId + "]]></MediaId></Voice>";
        }

        /// <summary>
        /// 语音文件id，可以调用上传媒体文件接口获取
        /// </summary>
        public string MediaId { get; set; }
    }
}
