﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebChatInterface.Class.Model.WXMsg.Response
{
    public abstract class BaseResponse
    {
        public BaseResponse(string msgType)
        {
            this.MsgType = msgType;
        }

        public string ToXmlString()
        {
            //在CDATA内部的所有内容都会被解析器忽略
            return "<xml><ToUserName><![CDATA[" + this.ToUserName +
                "]]></ToUserName><FromUserName><![CDATA[" + this.FromUserName +
                "]]></FromUserName><CreateTime>" + this.CreateTime +
                "</CreateTime><MsgType><![CDATA[" + this.MsgType +
                "]]></MsgType>" + ResponseXML() + "</xml>";
        }

        public abstract string ResponseXML();

        public string ToUserName { get; set; }
        public string FromUserName { get; set; }
        public string CreateTime { get; set; }
        public string MsgType { get; set; }
    }
}
