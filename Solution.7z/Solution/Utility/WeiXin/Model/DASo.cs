﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebChatInterface.Class.Model
{
    public class DASo
    {
        public DASo(string s, string n, bool prs, bool pts, bool cts, bool lgs,int ordqty,int finishqty)
        {
            this.so = s;
            this.name = n;
            this.printStatus = prs;
            this.partStatus = pts;
            this.cartonStatus = cts;
            this.lrgStatus = lgs;
            this.orderQty = ordqty;
            this.finishQty = finishqty;
        }
        public string so { get; set; }
        public string name { get; set; }
        public int orderQty { get; set; }
        public int finishQty { get; set; }
        public bool printStatus { get; set; }
        public bool partStatus { get; set; }
        public bool cartonStatus { get; set; }
        public bool lrgStatus { get; set; }
    }
}
