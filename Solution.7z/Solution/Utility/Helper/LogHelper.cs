﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using System.Diagnostics;

namespace Leo.Project.Common.Helper
{
    public enum LogType
    {
        Info = 1,
        Debug = 2,
        Warn = 3,
        Error = 4
    }

    public class LogHelper
    {
        public static void WriteLog(LogType logType,Type t, Exception ex)
        {
            ILog log = LogManager.GetLogger(t);
            switch (logType)
            {
                case LogType.Info:
                    log.Info(ex);
                    break;
                case LogType.Debug:
                    log.Debug(ex);
                    break;
                case LogType.Warn:
                    log.Warn(ex);
                    break;
                case LogType.Error:
                    log.Error(ex);
                    break;
                default:
                    log.Error(ex);
                    break;
            }
        }

        public static void WriteLog(LogType logType, Type t, string info)
        {
            ILog log = LogManager.GetLogger(t);
            switch (logType)
            {
                case LogType.Info:
                    log.Info(info);
                    break;
                case LogType.Debug:
                    log.Debug(info);
                    break;
                case LogType.Warn:
                    log.Warn(info);
                    break;
                case LogType.Error:
                    log.Error(info);
                    break;
                default:
                    log.Error(info);
                    break;
            }
        }

        public static void WriteLog(LogType logType, Type t, string info, Exception ex)
        {
            ILog log = LogManager.GetLogger(t);
            switch (logType)
            {
                case LogType.Info:
                    if (ex!=null) log.Info(info, ex);
                    else log.Info(info);
                    break;
                case LogType.Debug:
                    if (ex != null) log.Debug(info, ex);
                    else log.Debug(info);
                    break;
                case LogType.Warn:
                    if (ex != null) log.Warn(info, ex);
                    else log.Warn(info);
                    break;
                    /*
                case LogType.Error:
                    if (ex != null) log.Error(info, ex);
                    else log.Error(info);
                    break;
                     */
                default:
                    if (ex != null) log.Error(info, ex);
                    else log.Error(info);
                    break;
            }
        }

        public static void Info(string msg)
        {
            StackTrace trace = new StackTrace();
            WriteLog(LogType.Info, trace.GetFrame(1).GetMethod().DeclaringType, msg, null);
        }

        public static void Error(string msg, Exception error)
        {
            StackTrace trace = new StackTrace();
            WriteLog(LogType.Error, trace.GetFrame(1).GetMethod().DeclaringType, msg, error);
        }


        /*
        internal static void Error(string p, Exception ex)
        {
            throw new NotImplementedException();
        }
        */
    }


}
