﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Tools;

namespace Leo.Project.Common.Helper
{
    public static class SqlHelper
    {
        public static string DefaultConnectionString = "ConnectionString";
        public static int CommandTimeout = 300000;

        //ReflectionHelper.SetFieldValue(Type.GetType("LEO.Project.WXProposal.Data.DAO.SqlHelper").GetField("ConnectionString"), ConfigurationManager.ConnectionStrings["TiAnDB"].ToString().Trim());
        //ReflectionHelper.SetFieldValue(Type.GetType("LEO.Project.WXProposal.Data.DAO.SqlHelper").GetField("CommandTimeout"), Convert.ToInt32(ConfigurationManager.ConnectionStrings["CommandTimeout"]));

        public static SqlConnection GetConnection()
        {
            return GetConnection(DefaultConnectionString);
        }
        /// <summary>
        /// 將數據庫連接字符串解密
        /// </summary>
        /// <param name="ConnectionString"></param>
        /// <returns></returns>
        public static SqlConnection GetConnection(string ConnectionString)
        {
            SqlConnection cn = null;
            try
            {
                string constr = null;
                if (ConfigurationManager.ConnectionStrings != null && ConfigurationManager.ConnectionStrings[ConnectionString] != null && !string.IsNullOrEmpty(ConfigurationManager.ConnectionStrings[ConnectionString].ConnectionString))
                    constr = ConfigurationManager.ConnectionStrings[ConnectionString].ConnectionString;
                if (string.IsNullOrEmpty(constr) && System.Configuration.ConfigurationManager.AppSettings != null && !string.IsNullOrEmpty(System.Configuration.ConfigurationSettings.AppSettings[ConnectionString]))
                    constr = System.Configuration.ConfigurationSettings.AppSettings[ConnectionString];
                string decStr = AESHelper.AESDecrypt(constr);
                if (string.IsNullOrEmpty(decStr)) decStr = constr;
                cn = new SqlConnection(decStr);
                if (cn.State == ConnectionState.Closed) cn.Open();
            }
            catch (Exception ex)
            {
                //throw ex;
                LogHelper.Error("GetConnection Exception", ex);
                if (cn != null)
                {
                    if (cn.State == ConnectionState.Open) cn.Close();
                    cn.Dispose();
                }
            }
            finally
            {
            }
            return cn;

        }

        public static void ReleaseConnection(SqlConnection con)
        {
            if (con != null)
            {
                try
                {
                    if (con.State == ConnectionState.Open) con.Close();
                    con.Dispose();
                }
                catch (Exception ex)
                {
                    LogHelper.Error("ReleaseConnection Exception", ex);
                    //throw ex;
                }
                finally
                {
                }
            }
        }

        public static  SqlTransaction BeginTransaction(SqlConnection con)
        {
            try
            {
                if (con != null && con.State == ConnectionState.Open)
                {
                    return con.BeginTransaction();
                }
            }
            catch (Exception ex)
            {
                //throw ex;
                LogHelper.Error("BeginTransaction Exception", ex);
            }
            finally
            {
            }
            return null;
        }

        public static bool CommitTransaction(SqlTransaction trans)
        {
            try
            {
                if (trans != null)
                {
                    trans.Commit();
                    return true;
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error("CommitTransaction Exception", ex);
                //throw ex;
            }
            finally
            {
            }
            return false;
        }

        public static bool RollbackTransaction(SqlTransaction trans)
        {
            try
            {
                if (trans != null)
                {
                    trans.Rollback();
                    return true;
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error("RollbackTransaction Exception", ex);
                //throw ex;
            }
            finally
            {
            }
            return false;
        }

        public static int ExecuteNonQuery(SqlTransaction trans, string commandText)
        {
            return ExecuteNonQuery(trans, null, commandText, null);
        }

        public static int ExecuteNonQuery(SqlTransaction trans, string commandText, SqlParameter[] sqlParams)
        {
            return ExecuteNonQuery(trans, null, commandText, sqlParams);
        }

        public static int ExecuteNonQuery(SqlConnection conn, string commandText)
        {
            return ExecuteNonQuery(null, conn, commandText, null);
        }

        public static int ExecuteNonQuery(SqlConnection conn, string commandText, SqlParameter[] sqlParams)
        {
            return ExecuteNonQuery(null, conn, commandText, sqlParams);
        }

        public static int ExecuteNonQuery(string commandText, SqlParameter[] sqlParams)
        {
            return ExecuteNonQuery(null, null, commandText, sqlParams);
        }

        public static int ExecuteNonQuery(string commandText)
        {
            return ExecuteNonQuery(commandText, null);
        }

        /// <summary>
        /// 執行帶參數的非查詢SQL語句
        /// </summary>
        /// <param name="commandText">SQL語句</param>
        /// <param name="sqlParams">參數</param>
        /// <returns></returns>
        private static int ExecuteNonQuery(SqlTransaction trans, SqlConnection conn, string commandText, SqlParameter[] sqlParams)
        {
            //if (true) return 1;
            SqlConnection cn = null;
            SqlCommand cmd = null;
            try
            {
                cn = trans != null ? trans.Connection : (conn != null ? conn : GetConnection());
                if (cn.State == ConnectionState.Closed) cn.Open();
                cmd = new SqlCommand(commandText, cn);
                if (trans != null) cmd.Transaction = trans;
                cmd.CommandTimeout = CommandTimeout;
                cmd.CommandType = CommandType.Text;
                if (sqlParams != null)
                {
                    foreach (SqlParameter param in sqlParams)
                        cmd.Parameters.Add(param);
                }
                return cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                LogHelper.Error("ExecuteNonQuery Error!", ex);
                //throw ex;
                return -1;
            }
            finally
            {
                if (cmd != null)
                {
                    cmd.Parameters.Clear();
                    cmd.Dispose();
                }
                if (trans == null && conn == null)
                {
                    if (cn != null)
                    {
                        if (cn.State == ConnectionState.Open) cn.Close();
                        cn.Dispose();
                    }
                }
            }

        }

        public static object ExecuteScalar(string commandText)
        {
            return ExecuteScalar(null, null, commandText, null);
        }

        public static object ExecuteScalar(string commandText, SqlParameter[] sqlParams)
        {
            return ExecuteScalar(null, null, commandText, sqlParams);
        }

        /// <summary>
        /// 執行SQL語句并返回結果集第一行第一列數據
        /// </summary>
        /// <author>JimyLi</author>
        /// <param name="commandText">SQL語句</param>
        /// <returns>object對象</returns>
        public static object ExecuteScalar(SqlTransaction trans, string commandText)
        {
            return ExecuteScalar(trans, null, commandText, null);
        }

        public static object ExecuteScalar(SqlConnection conn, string commandText)
        {
            return ExecuteScalar(null, conn, commandText, null);
        }

        /// <summary>
        /// 執行帶參數的SQL語句并返回結果集第一行第一列數據
        /// </summary>
        /// <author>JimyLi</author>
        /// <param name="commandText">SQL語句</param>
        /// <param name="sqlParams">參數</param>
        /// <returns>object對象</returns>
        public static object ExecuteScalar(SqlTransaction trans, string commandText, SqlParameter[] sqlParams)
        {
            return ExecuteScalar(trans, null, commandText, sqlParams);
        }

        public static object ExecuteScalar(SqlConnection conn, string commandText, SqlParameter[] sqlParams)
        {
            return ExecuteScalar(null, conn, commandText, sqlParams);
        }

        private static object ExecuteScalar(SqlTransaction trans, SqlConnection conn, string commandText, SqlParameter[] sqlParams)
        {
            //if (true) return 1;
            SqlConnection cn = null;
            SqlCommand cmd = null;
            try
            {
                cn = trans != null ? trans.Connection : (conn != null ? conn : GetConnection());
                if (cn.State == ConnectionState.Closed) cn.Open();
                cmd = new SqlCommand(commandText, cn);
                if (trans != null) cmd.Transaction = trans;
                cmd.CommandTimeout = CommandTimeout;
                cmd.CommandType = CommandType.Text;
                if (sqlParams != null)
                {
                    foreach (SqlParameter param in sqlParams)
                        cmd.Parameters.Add(param);
                }
                return cmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                LogHelper.Error("ExecuteScalar Error!", ex);
                //throw ex;
                return -1;
            }
            finally
            {
                if (cmd != null)
                {
                    cmd.Parameters.Clear();
                    cmd.Dispose();
                }
                if (trans == null && conn == null)
                {
                    if (cn != null)
                    {
                        if (cn.State == ConnectionState.Open) cn.Close();
                        cn.Dispose();
                    }
                }
            }

        }

        public static DataSet ExecuteDataset(string commandText)
        {
            return ExecuteDataset(null, null, commandText, null);
        }

        public static DataSet ExecuteDataset(string commandText, SqlParameter[] sqlParams)
        {
            return ExecuteDataset(null, null, commandText, sqlParams);
        }

        public static DataSet ExecuteDataset(SqlConnection conn, string commandText, SqlParameter[] sqlParams)
        {
            return ExecuteDataset(null, conn, commandText, sqlParams);
        }

        public static DataSet ExecuteDataset(SqlTransaction trans, string commandText, SqlParameter[] sqlParams)
        {
            return ExecuteDataset(trans, null, commandText, sqlParams);
        }

        private static DataSet ExecuteDataset(SqlTransaction trans, SqlConnection conn, string commandText, SqlParameter[] sqlParams)
        {
            SqlConnection cn = null;
            SqlCommand cmd = null;
            SqlDataAdapter da = null;
            DataSet ds = null;
            try
            {
                cn = trans != null ? trans.Connection : (conn != null ? conn : GetConnection());
                if (cn.State == ConnectionState.Closed) cn.Open();
                cmd = new SqlCommand(commandText, cn);
                if (trans != null) cmd.Transaction = trans;
                cmd.CommandTimeout = CommandTimeout;
                cmd.CommandType = CommandType.Text;
                if (sqlParams != null)
                {
                    foreach (SqlParameter param in sqlParams)
                        cmd.Parameters.Add(param);
                }
                da = new SqlDataAdapter(cmd);
                ds = new DataSet();
                da.Fill(ds);
                return ds;
            }
            catch (Exception ex)
            {
                LogHelper.Error("ExecuteDataset Error!", ex);
                throw ex;
            }
            finally
            {
                if (trans==null && conn == null)
                {
                    if (cn.State == ConnectionState.Open) cn.Close();
                    if (cn != null) cn.Dispose();
                }
                if (cmd != null)
                {
                    cmd.Parameters.Clear();
                    cmd.Dispose();
                }
                if (da != null) da.Dispose();
                if (ds != null) ds.Dispose();
            }
        }

        #region 暂时用不上

        /// <summary>
        /// 取得DataSet
        /// </summary>
        /// <param name="trans">事務</param>
        /// <param name="cmdType">操作類型</param>
        /// <param name="cmdText">操作語句</param>
        /// <param name="commandParameters">參數</param>
        /// <returns></returns>
        public static DataSet ExecuteDataset(SqlTransaction trans, CommandType cmdType, string cmdText, params SqlParameter[] commandParameters)
        {
            SqlCommand cmd = new SqlCommand();
            PrepareCommand(cmd, trans.Connection, trans, cmdType, cmdText, commandParameters);

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);

            return ds;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="conn">連接</param>
        /// <param name="cmdType">操作類型</param>
        /// <param name="cmdText">操作語句</param>
        /// <param name="commandParameters">參數</param>
        /// <returns></returns>
        public static DataSet ExecuteDataset(SqlConnection conn, CommandType cmdType, string cmdText, params SqlParameter[] commandParameters)
        {
            SqlCommand cmd = new SqlCommand();
            PrepareCommand(cmd, conn, null, cmdType, cmdText, commandParameters);

            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);

            return ds;
        }

        /// <summary>
        /// 執行SQL
        /// </summary>
        /// <param name="conn">連接</param>
        /// <param name="cmdType">操作類型</param>
        /// <param name="cmdText">操作語句</param>
        /// <param name="commandParameters">參數</param>
        /// <returns></returns>
        public static int ExecuteNonQuery(SqlConnection conn, CommandType cmdType, string cmdText, params SqlParameter[] commandParameters)
        {
            SqlCommand cmd = new SqlCommand();
            PrepareCommand(cmd, conn, null, cmdType, cmdText, commandParameters);
            int l_intReturn = 0;
            try
            {
                l_intReturn = cmd.ExecuteNonQuery();
            }
            catch
            {
                throw;
            }
            return l_intReturn;
        }

        /// <summary>
        /// 執行SQL
        /// </summary>
        /// <param name="trans">事務</param>
        /// <param name="cmdType">操作類型</param>
        /// <param name="cmdText">操作語句</param>
        /// <param name="commandParameters">參數</param>
        /// <returns></returns>
        public static int ExecuteNonQuery(SqlTransaction trans, CommandType cmdType, string cmdText, params SqlParameter[] commandParameters)
        {
            SqlCommand cmd = new SqlCommand();
            PrepareCommand(cmd, trans.Connection, trans, cmdType, cmdText, commandParameters);

            int l_intReturn = 0;
            try
            {
                l_intReturn = cmd.ExecuteNonQuery();
            }
            catch
            {
                throw;
            }

            return l_intReturn;
        }

        /// <summary>
        /// 執行SQL取得DataReader
        /// </summary>
        /// <param name="conn">連接</param>
        /// <param name="tran">事務</param>
        /// <param name="cmdType">操作類型</param>
        /// <param name="cmdText">操作語句</param>
        /// <param name="cmdParms">參數</param>
        /// <returns></returns>
        public static SqlDataReader ExecuteReader(SqlConnection conn, CommandType cmdType, string cmdText, SqlParameter[] cmdParms)
        {
            SqlCommand cmd = new SqlCommand();
            try
            {
                PrepareCommand(cmd, conn, null, cmdType, cmdText, cmdParms);
                SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                return rdr;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// 整理Command
        /// </summary>
        /// <param name="cmd">SqlCommand</param>
        /// <param name="conn">連接</param>
        /// <param name="trans">事務</param>
        /// <param name="cmdType">操作類型</param>
        /// <param name="cmdText">操作語句</param>
        /// <param name="cmdParms">參數</param>
        private static void PrepareCommand(SqlCommand cmd, SqlConnection conn, SqlTransaction trans, CommandType cmdType, string cmdText, SqlParameter[] cmdParms)
        {
            if (conn.State != ConnectionState.Open)
                conn.Open();

            cmd.Connection = conn;
            cmd.CommandText = cmdText;

            if (trans != null)
                cmd.Transaction = trans;

            cmd.CommandType = cmdType;

            if (cmdParms != null)
            {
                foreach (SqlParameter parm in cmdParms)
                    cmd.Parameters.Add(parm);
            }
        }

        #endregion

        /// <summary>
        /// 整理參數
        /// </summary>
        /// <param name="ParamName">參數名</param>
        /// <param name="DbType">參數類型</param>
        /// <param name="Size">大小</param>
        /// <param name="Value">值</param>
        /// <returns></returns>
        public static SqlParameter MakeInParam(string ParamName, SqlDbType DbType, int Size, object Value)
        {
            return MakeParam(ParamName, DbType, Size, ParameterDirection.Input, Value);
        }

        /// <summary>
        /// 整理參數
        /// </summary>
        /// <param name="ParamName">參數名</param>
        /// <param name="DbType">參數類型</param>
        /// <param name="Size">大小</param>
        /// <returns></returns>
        public static SqlParameter MakeOutParam(string ParamName, SqlDbType DbType, int Size)
        {
            return MakeParam(ParamName, DbType, Size, ParameterDirection.Output, null);
        }

        /// <summary>
        /// 整理參數
        /// </summary>
        /// <param name="ParamName">參數名</param>
        /// <param name="DbType">參數類型</param>
        /// <param name="Size">大小</param>
        /// <param name="Direction">參數類型</param>
        /// <param name="Value">值</param>
        /// <returns></returns>
        public static SqlParameter MakeParam(string ParamName, SqlDbType DbType, Int32 Size, ParameterDirection Direction, object Value)
        {
            SqlParameter param;

            if (Size > 0)
                param = new SqlParameter(ParamName, DbType, Size);
            else
                param = new SqlParameter(ParamName, DbType);

            /*
            param.Direction = Direction;
            if (!(Direction == ParameterDirection.Output && Value == null))
                param.Value = Value;
            */
            if (Direction == ParameterDirection.Input)
            {
                if (Value == null) param.Value = DBNull.Value;
                else
                {
                    //if ((Value is string || Value.GetType() == typeof(string)) && ((string)Value).Length > Size)
                    if (Value is string && ((string)Value).Length > Size)
                    {
                        param.Value = ((string)Value).Substring(0, Size);
                    }
                    else param.Value = Value;
                }
            }
            return param;
        }

        /// <summary>
        /// 關閉連接
        /// </summary>
        /// <param name="conn">連接</param>
        public static void CloseConnection(SqlConnection conn)
        {
            if (conn != null)
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

    }
}
