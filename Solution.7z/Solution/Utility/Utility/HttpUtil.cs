﻿using System;
using System.Text;
using System.Web;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Security.Principal;
using System.Configuration;

namespace Leo.Project.Common.Utility
{
    public class HttpUtil
    {
        //private static NetworkCredential proxyCredential = new NetworkCredential("ntlogin", "pass", "hsgroup");
        private static NetworkCredential proxyCredential = null;
        private static System.Net.WebProxy defaultWebProxy = null;

        /// <summary>
        /// 读取请求对象的内容
        /// 只能读一次
        /// </summary>
        /// <param name="request">HttpRequest对象</param>
        /// <returns>string</returns>
        public static string ReadRequest(HttpRequest request)
        {
            string reqStr = string.Empty;
            using (Stream s = request.InputStream)
            {
                using (StreamReader reader = new StreamReader(s, Encoding.UTF8))
                {
                    reqStr = reader.ReadToEnd();
                }
            }
            return reqStr;
        }

        /// <summary>
        /// 使用Get方法获取字符串结果（没有加入Cookie）
        /// </summary>
        /// <param name="url"></param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        public static string HttpWebClientGet(string url, Encoding encoding)
        {
            WebClient wc = new WebClient();
            wc.Encoding = encoding ?? Encoding.UTF8;
            return wc.DownloadString(url);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="url"></param>
        /// <param name="encoding"></param>
        /// <returns></returns>
        public static string HttpGet(string url, Encoding encoding)
        {
            System.Net.HttpWebRequest request = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(url);
            // add by jimyli ---
            if (defaultWebProxy != null)
            {
                if (proxyCredential != null) defaultWebProxy.Credentials = proxyCredential;
                request.Proxy = defaultWebProxy;
            }
            // add by jimyli ---

            if (Convert.ToString(ConfigurationManager.AppSettings["ProxyStatus"]).ToLower()=="true")
            {
                WebProxy proxy = new WebProxy();
                proxy.Address = new Uri("http://hserpdb01:808/");
                request.Proxy = proxy;
            }

            request.Method = "get";

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            using (Stream responseStream = response.GetResponseStream())
            {
                using (StreamReader myStreamReader = new StreamReader(responseStream, encoding ?? Encoding.GetEncoding("utf-8")))
                {
                    string retString = myStreamReader.ReadToEnd();
                    return retString;
                }
            }

        }

        public static string HttpPost(string url, string postData, Encoding encoding, CookieContainer cookieContainer)
        {
            var postBytes = postData == null ? new byte[0] : Encoding.UTF8.GetBytes(postData);


            HttpWebRequest request = WebRequest.Create(url) as HttpWebRequest;
            // add by jimyli ---
            if (defaultWebProxy != null)
            {
                if (proxyCredential != null) defaultWebProxy.Credentials = proxyCredential; 
                request.Proxy = defaultWebProxy;
            }

            //add by riocas
            if (Convert.ToString(ConfigurationManager.AppSettings["ProxyStatus"]).ToLower() == "true")
            {
                WebProxy proxy = new WebProxy();
                proxy.Address = new Uri("http://hserpdb01:808/");
                request.Proxy = proxy;
            }

            // add by jimyli ---
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = postBytes.Length;
            request.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8";
            request.KeepAlive = true;

            if (cookieContainer != null)
            {
                request.CookieContainer = cookieContainer;
            }


            //直接写入流
            Stream requestStream = request.GetRequestStream();
            requestStream.Write(postBytes, 0, postBytes.Length);


            requestStream.Close();//关闭文件访问

            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            if (cookieContainer != null)
            {
                response.Cookies = cookieContainer.GetCookies(response.ResponseUri);
            }

            using (Stream responseStream = response.GetResponseStream())
            {
                using (StreamReader myStreamReader = new StreamReader(responseStream, encoding ?? Encoding.GetEncoding("utf-8")))
                {
                    string retString = myStreamReader.ReadToEnd();
                    return retString;
                }
            }
        }


        /// <summary>
        /// 判断是否有乱码
        /// </summary>
        /// <param name="txt"></param>
        /// <returns></returns>
        public static bool isMessyCode(string txt)
        {
            var bytes = Encoding.UTF8.GetBytes(txt);            //239 191 189            
            for (var i = 0; i < bytes.Length; i++)
            {
                if (i < bytes.Length - 3)
                    if (bytes[i] == 239 && bytes[i + 1] == 191 && bytes[i + 2] == 189)
                    {
                        return true;
                    }
            }
            return false;
        }

        /// <summary>
        /// 判断使用哪种编码獲取网页內容
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public static string getWebContent(string url)
        {
            try
            {
                WebClient MyWebClient = new WebClient();
                MyWebClient.Credentials = CredentialCache.DefaultCredentials;//获取或设置用于向Internet资源的请求进行身份验证的网络凭据
                MyWebClient.Encoding = Encoding.UTF8;
                Byte[] pageData = MyWebClient.DownloadData(url);//从指定网站下载数据
                string pageHtml = Encoding.UTF8.GetString(pageData); //从指定网站下载数据    
                bool isBool = isMessyCode(pageHtml);//判断使用哪种编码 读取网页信息
                if (!isBool)
                {
                    string pageHtml1 = Encoding.UTF8.GetString(pageData);
                    pageHtml = pageHtml1;
                }
                else
                {
                    string pageHtml2 = Encoding.Default.GetString(pageData);
                    pageHtml = pageHtml2;
                }
                return pageHtml;
            }

            catch (WebException webEx)
            {
                Console.WriteLine(webEx.Message.ToString());
                return webEx.Message;
            }
        }

        #region 獲取當前登錄NT用戶
        /// <summary>
        /// 獲取當前登錄NT用戶
        /// </summary>
        /// <param name="httpContext"></param>
        /// <returns></returns>
        public static string GetHttpContextNTFullName(HttpContext httpContext)
        {
            if (httpContext != null && httpContext.User != null && httpContext.User.Identity != null &&
                !string.IsNullOrEmpty(httpContext.User.Identity.Name))
            {
                return httpContext.User.Identity.Name;
            }
            else return null;
        }
        #endregion

        #region 获取客户端IP地址

        /// <summary>  
        /// 获取客户端IP地址  
        /// </summary>  
        /// <returns></returns>  
        public static string GetIP(HttpRequest request)
        {
            string result = request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (string.IsNullOrEmpty(result))
            {
                result = request.ServerVariables["REMOTE_ADDR"];
            }
            if (string.IsNullOrEmpty(result))
            {
                result = request.UserHostAddress;
            }
            if (string.IsNullOrEmpty(result))
            {
                return "0.0.0.0";
            }
            return result;
        }

        #endregion

        #region 取客户端真实IP

        ///  <summary>    
        ///  取得客户端真实IP。如果有代理则取第一个非内网地址    
        ///  </summary>    
        public static string GetIPAddress(HttpRequest request)
        {

            var result = request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (!string.IsNullOrEmpty(result))
            {
                //可能有代理    
                if (result.IndexOf(".") == -1)        //没有“.”肯定是非IPv4格式    
                    result = null;
                else
                {
                    if (result.IndexOf(",") != -1)
                    {
                        //有“,”，估计多个代理。取第一个不是内网的IP。    
                        result = result.Replace("  ", "").Replace("'", "");
                        string[] temparyip = result.Split(",;".ToCharArray());
                        for (int i = 0; i < temparyip.Length; i++)
                        {
                            if (IsIPAddress(temparyip[i])
                                    && temparyip[i].Substring(0, 3) != "10."
                                    && temparyip[i].Substring(0, 7) != "192.168"
                                    && temparyip[i].Substring(0, 7) != "172.16.")
                            {
                                return temparyip[i];        //找到不是内网的地址    
                            }
                        }
                    }
                    else if (IsIPAddress(result))  //代理即是IP格式    
                        return result;
                    else
                        result = null;        //代理中的内容  非IP，取IP    
                }

            }

            string IpAddress = (request.ServerVariables["HTTP_X_FORWARDED_FOR"] != null && request.ServerVariables["HTTP_X_FORWARDED_FOR"] != String.Empty) ? request.ServerVariables["HTTP_X_FORWARDED_FOR"] : request.ServerVariables["HTTP_X_REAL_IP"];

            if (string.IsNullOrEmpty(result))
                result = request.ServerVariables["HTTP_X_REAL_IP"];

            if (string.IsNullOrEmpty(result))
                result = request.UserHostAddress;

            return result;
        }

        #endregion

        #region  判断是否是IP格式

        ///  <summary>  
        ///  判断是否是IP地址格式  0.0.0.0  
        ///  </summary>  
        ///  <param  name="str1">待判断的IP地址</param>  
        ///  <returns>true  or  false</returns>  
        public static bool IsIPAddress(string str1)
        {
            if (string.IsNullOrEmpty(str1) || str1.Length < 7 || str1.Length > 15) return false;

            const string regFormat = @"^d{1,3}[.]d{1,3}[.]d{1,3}[.]d{1,3}$";

            var regex = new Regex(regFormat, RegexOptions.IgnoreCase);
            return regex.IsMatch(str1);
        }

        #endregion

        #region 获取公网IP
        /// <summary>  
        /// 获取公网IP  
        /// </summary>  
        /// <returns></returns>  
        public static string GetNetIP(HttpRequest request)
        {
            string tempIP = "";
            try
            {
                System.Net.WebRequest wr = System.Net.WebRequest.Create("http://city.ip138.com/ip2city.asp");
                System.IO.Stream s = wr.GetResponse().GetResponseStream();
                System.IO.StreamReader sr = new System.IO.StreamReader(s, System.Text.Encoding.GetEncoding("gb2312"));
                string all = sr.ReadToEnd(); //读取网站的数据  

                int start = all.IndexOf("[") + 1;
                int end = all.IndexOf("]", start);
                tempIP = all.Substring(start, end - start);
                sr.Close();
                s.Close();
            }
            catch
            {
                if (System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName()).AddressList.Length > 1)
                    tempIP = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName()).AddressList[1].ToString();
                if (string.IsNullOrEmpty(tempIP))
                    return GetIP(request);
            }
            return tempIP;
        }
        #endregion


    }
}
