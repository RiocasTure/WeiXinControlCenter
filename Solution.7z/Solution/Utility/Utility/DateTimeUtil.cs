﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Globalization;

namespace Leo.Project.Common.Utility
{
    public static class DateTimeUtil
    {
        private static readonly DateTime Jan1St1970 = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        /// <summary>Get extra long current timestamp</summary>
        public static long CurrentMillis { get { return (long)((DateTime.UtcNow - Jan1St1970).TotalMilliseconds); } }

        public static long GetMillis(DateTime datetime)
        {
            return (long)((datetime.ToUniversalTime() - Jan1St1970).TotalMilliseconds);
        }

        public static DateTime ToDateTimeFromMillis(long millis)
        {
            return (new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).AddMilliseconds(millis).ToLocalTime();
        }

        public static DateTime? ParseDateTime(string format, string datetimeStr)
        {
            DateTime? date = null;
            try
            {
                date = DateTime.ParseExact(datetimeStr, format, CultureInfo.InvariantCulture);

            }
            catch (Exception)
            {
            }
            return date;
        }

        public static readonly string FormatYMD = "yyyy-MM-dd";
        public static readonly string FormatDMY = "dd/MM/yyyy";
        public static readonly string FormatDMYHM = "dd/MM/yyyy HH:mm";

    }

    public enum DateInterval
    {
        MiliSecond, Second, Minute, Hour, Day, Week, Month, Quarter, Year
    }
    public sealed class DateTimeManger
    {
        private DateTimeManger()
        { }//end of default constructor
        public static long DateDiff(DateInterval Interval, System.DateTime StartDate, System.DateTime EndDate)
        {
            long lngDateDiffValue = 0;
            System.TimeSpan TS = new System.TimeSpan(EndDate.Ticks - StartDate.Ticks);
            switch (Interval)
            {
                case DateInterval.MiliSecond:
                    lngDateDiffValue = (long)TS.TotalMilliseconds;
                    break;
                case DateInterval.Second:
                    lngDateDiffValue = (long)TS.TotalSeconds;
                    break;
                case DateInterval.Minute:
                    lngDateDiffValue = (long)TS.TotalMinutes;
                    break;
                case DateInterval.Hour:
                    lngDateDiffValue = (long)TS.TotalHours;
                    break;
                case DateInterval.Day:
                    lngDateDiffValue = (long)TS.Days;
                    break;
                case DateInterval.Week:
                    lngDateDiffValue = (long)(TS.Days / 7);
                    break;
                case DateInterval.Month:
                    lngDateDiffValue = (long)(TS.Days / 30);
                    break;
                case DateInterval.Quarter:
                    lngDateDiffValue = (long)((TS.Days / 30) / 3);
                    break;
                case DateInterval.Year:
                    lngDateDiffValue = (long)(TS.Days / 365);
                    break;
            }
            return (lngDateDiffValue);
        }//end of DateDiff
    }//end of class

}
