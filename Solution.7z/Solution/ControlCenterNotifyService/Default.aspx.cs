﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
//using WebChatInterface.Class.Tencent;
using LEO.Common.Tools.WeiXin;
using Newtonsoft.Json.Linq;
using Tools;
using Leo.Project.Common.Helper;
using Leo.Project.Common.Utility;
using WebChatInterface.Class.Tencent;

namespace ControlCenterNotifyService
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string code = Request.Params["code"];
                string state = Request.Params["state"];
                string userId = null;
                string deviceId = null;
                if (!string.IsNullOrEmpty(code))
                {
                    string token = WeiXinUtils.GetAccessToken(Server.MapPath("~/bin/accessToken.json"));
                    if (!string.IsNullOrEmpty(token))
                    {
                        string url = string.Format("https://qyapi.weixin.qq.com/cgi-bin/user/getuserinfo?access_token={0}&code={1}", token, code);
                        string jsonText = HttpUtil.HttpGet(url, Encoding.UTF8);
                        if (!string.IsNullOrEmpty(jsonText))
                        {
                            JObject o = JObject.Parse(jsonText);
                            userId = o.SelectToken("$.UserId").ToString();
                            deviceId = o.SelectToken("$.DeviceId").ToString();
                            HttpCookie uCookie = new HttpCookie("WXUserID", userId);
                            HttpCookie dCookie = new HttpCookie("WXDeviceId", deviceId);
                            Response.Cookies.Add(uCookie);//HttpContext.Current.
                            Response.Cookies.Add(dCookie);
                        }
                    }
                }
                else
                {
                    HttpCookie uidCookie = Request.Cookies["WXUserID"];
                    HttpCookie didCookie = Request.Cookies["WXDeviceId"];
                    if (uidCookie != null) userId = uidCookie.Value;
                    if (didCookie != null) deviceId = didCookie.Value;
                }
                if (!string.IsNullOrEmpty(userId) && !string.IsNullOrEmpty(deviceId))
                {
                    Response.Redirect("http://www.astros.com.cn/01/demo/cc-follow.html?state=" + state,false);
                    Context.ApplicationInstance.CompleteRequest();
                    //Response.End();
                    return;
                }
                if (string.IsNullOrEmpty(code) && !string.IsNullOrEmpty(state))
                {
                    string authUrl = string.Format(
                        "https://open.weixin.qq.com/connect/oauth2/authorize?appid={0}&redirect_uri={1}&response_type=code&scope={2}&state={3}#wechat_redirect",
                        WeiXinAccount.CorpID, HttpUtility.UrlEncode("http://www.astros.com.cn/01/demo/cc/Default.aspx"), "snsapi_base", HttpUtility.UrlEncode(state));
                    Response.Redirect(authUrl,false);
                    Context.ApplicationInstance.CompleteRequest();
                    //Response.End();
                    return;
                }
                Response.Write("Welcome!");
                //Response.Redirect("http://10.2.2.167/01/live/",false);
                //Context.ApplicationInstance.CompleteRequest();
            }
            catch (Exception ae)
            {
                LogHelper.Error("Exception", ae);
            }
        }
    }
}
