﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Leo.Project.CC.DAO;
using Leo.Project.CC.Model;
using DAO;
//using WebChatInterface.Class.Model.WXMsg.Send;
using LEO.Common.Tools.WeiXin;
using System.IO;
using Leo.Project.Common.Helper;
//using WebChatInterface.Class.Tencent;
using System.Text;
using Tools;
using WebChatInterface.Class.Model.WXMsg.Send;
using WebChatInterface.Class.Tencent;
using Leo.Project.Common.Utility;

namespace ControlCenterNotifyService
{
    /// <summary>
    /// Summary description for WXNotify
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class WXNotifyService : System.Web.Services.WebService
    {

        [WebMethod]
        public WXNotify GetWXNotifyInfo(int ID)
        {
            WXNotify notify = WXNotifyDAO.Instance.GetByKey(ID);
            if (notify != null && notify.CheckID > 0)
            {
                notify.CheckInfo = ProductionCheckDAO.Instance.GetByKey(notify.CheckID);
            }
            return notify;
        }
        [WebMethod]
        public WXNotify NotifyResponse(int ID, string action, string userId, string deviceId)
        {
            WXNotify notify = WXNotifyDAO.Instance.GetByKey(ID);
            if (notify != null)
            {
                if (notify.Target == userId && (
                    (notify.Status == Constants.WXNotify_Status_Sent && "f" == action) ||
                    (notify.Status == Constants.WXNotify_Status_Following && "d" == action) ||
                    (notify.Status == Constants.WXNotify_Status_Sent && "u" == action) ||
                    (notify.Status == Constants.WXNotify_Status_Following && "u" == action)))
                {
                    string statusBak = notify.Status;
                    if ("f" == action) notify.Status = Constants.WXNotify_Status_Following;
                    if ("d" == action) notify.Status = Constants.WXNotify_Status_Finished;
                    if ("u" == action) notify.Status = Constants.WXNotify_Status_Upgrade;
                    UserResponse ur = new UserResponse();
                    ur.NotifyID = notify.ID;
                    ur.UserID = notify.Target;
                    ur.DeviceID = deviceId;
                    ur.Type = notify.Status;
                    ur.UpdateTime = DateTime.Now;
                    int result = UserResponseDAO.Instance.Insert(ur);
                    if (result > 0)
                    {
                        notify.LastUpdate = DateTime.Now;
                        result = WXNotifyDAO.Instance.Update(notify);

                        //微信通知
                        if (result > 0)
                        {
                            notify.CheckInfo = ProductionCheckDAO.Instance.GetByKey(notify.CheckID);
                            SendNews news = new SendNews();
                            news.AgentID = "1000002";//团队接收
                            news.ToParties = "4";//群組⇒
                            string title =
                                notify.Status == Constants.WXNotify_Status_Following ? "→接收並跟進處理中" : (
                                notify.Status == Constants.WXNotify_Status_Finished ? "✓已完成跟進" : (
                                notify.Status == Constants.WXNotify_Status_Upgrade ? "↑需升級處理" : ""));
                            string desc = 
                                notify.WarnType==Constants.WXNotify_WarnType_LowSpeed?
                                (notify.WarnType+"，"+notify.CheckInfo.Superviser + "\r\n" + notify.CheckInfo.LineName + "，效率" + notify.CheckInfo.CurrentComplianceRate + "%\r\n　" + notify.CheckInfo.SO + "，" + notify.CheckInfo.ProcessName + "\r\n　PE定額" + notify.CheckInfo.PEPlanQtyPer + "\r\n　現場定額" + notify.CheckInfo.PlanQtyPer):(
                                notify.WarnType==Constants.WXNotify_WarnType_ReportTimeout?
                                (notify.WarnType + "，" + notify.CheckInfo.Superviser + "\r\n" + notify.CheckInfo.LineName + "，" + notify.CheckInfo.SO + "\r\n　上次報數：" + (notify.CheckInfo.LastReportTime.HasValue ? notify.CheckInfo.LastReportTime.Value.ToString("HH:mm") : "未報數")) : "");
                            if (!string.IsNullOrEmpty(title) && !string.IsNullOrEmpty(desc))
                            {
                                news.AddNewsItem(title, desc, "", "");
                                string token = WeiXinUtils.GetAccessToken(Server.MapPath("~/bin/accessToken.json"));
                                if (token == null)
                                    LogHelper.Error("AccessToken Error!", null);
                                else
                                {
                                    string sendPostUrl = WeiXinAccount.Url_SendMessage.Replace("${ACCESS_TOKEN}", token);
                                    string postResponse = (string.IsNullOrEmpty(news.ToUsers) && string.IsNullOrEmpty(news.ToParties) && string.IsNullOrEmpty(news.ToTags)) ? "Empty WeiXin News!" : HttpUtil.HttpPost(sendPostUrl, news.ToJSON(), Encoding.UTF8, null);
                                    if (!string.IsNullOrEmpty(postResponse))
                                        LogHelper.Info(postResponse);
                                }
                            }
                        }
                        else
                        {
                            notify.Status = statusBak;
                        }
                        return notify;
                    }
                }
            }
            return null;
        }
        [WebMethod]
        public int Test()
        {
            return 1;
        }
    }
}
